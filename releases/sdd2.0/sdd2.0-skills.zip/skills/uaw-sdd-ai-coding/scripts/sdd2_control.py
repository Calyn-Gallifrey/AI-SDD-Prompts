#!/usr/bin/env python3
"""UAW-SDD 2.0 的旧控制器维护对照实现。

正式 Skill 运行时只调用 Java 8 JAR；本文件仅用于维护回归和迁移比对。
"""

from __future__ import annotations

import argparse
import datetime as dt
import fnmatch
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import uuid
from pathlib import Path
from typing import Any, Iterable


SCHEMA_VERSION = "2.0.0"
CONTROL_DIR = ".sdd2"
STATE_FILE = "feature-state.json"
APPROVAL_FILE = "gate-approvals.jsonl"
EVENT_FILE = "events.jsonl"
SCOPE_FILE = "implementation-scope.json"
ARCHIVE_EVIDENCE_FILE = "archive-evidence.json"
UNIT_TEST_EVIDENCE_FILE = "unit-test-evidence.json"
REVISION_DIR = "revisions"
PREMATURE_CHANGE_BLOCK = "PREMATURE_IMPLEMENTATION_CHANGE"
FEATURE_LAYOUT_BLOCK = "UNEXPECTED_FEATURE_LAYOUT"
COMMIT_GUARD_MARKER = "# UAW-SDD2 GIT GUARD v1"
COMMIT_GUARD_HOOKS = ("prepare-commit-msg", "pre-push")

ARTIFACT_FILES = {
    "brief-design": "brief-design.md",
    "proposal-input": "proposal-input.md",
    "spec": "spec.md",
    "design": "design.md",
    "tasks": "tasks.md",
    "code-review-findings": "code-review-findings.md",
    "auto-fix-summary": "auto-fix-summary.md",
    "unit-test-summary": "unit-test-summary.md",
    "archive": "archive.md",
}
ARTIFACT_STAGE_BY_FILENAME = {
    filename: stage for stage, filename in ARTIFACT_FILES.items()
}
ALWAYS_CONTROL_FILENAMES = {
    STATE_FILE,
    APPROVAL_FILE,
    EVENT_FILE,
}
NEXT_ACTION_ARTIFACT_STAGE = {
    "assemble-proposal-input": "proposal-input",
    "generate-spec": "spec",
    "generate-design": "design",
    "generate-tasks": "tasks",
    "run-code-review": "code-review-findings",
    "record-auto-fix-not-required-or-current-fixes": "auto-fix-summary",
    "apply-review-findings": "auto-fix-summary",
    "generate-unit-test-summary-from-evidence": "unit-test-summary",
    "generate-archive-from-evidence": "archive",
}
REVISION_SNAPSHOT_PATTERN = re.compile(
    r"^\.sdd2/revisions/([a-z0-9-]+)/r([0-9]{4,})-([0-9a-f]{64})\.md$"
)

STAGE_ORDER = [
    "brief-design",
    "proposal-input",
    "spec",
    "design",
    "tasks",
    "implementation",
    "code-review",
    "auto-fix",
    "unit-test-summary",
    "archive",
]

APPROVAL_STAGES = {"spec", "design", "tasks", "unit-test-summary", "archive"}
QUALITY_GATES = {"code-review", "auto-fix", "unit-test"}
TERMINAL_STATUSES = {"completed", "closed-with-risk", "aborted", "superseded"}
PASS_WORDS = ("批准", "通过", "同意", "approve", "approved", "accept")
STAGE_WORDS = {
    "spec": ("spec", "需求规格", "需求"),
    "design": ("design", "设计"),
    "tasks": ("tasks", "任务"),
    "unit-test-summary": ("unit test summary", "unit-test-summary", "单元测试总结", "测试总结"),
    "archive": ("archive", "归档"),
}
APPROVAL_PATTERN = re.compile(r"(?:批准|通过|同意|\bapprove(?:d)?\b|\baccept(?:ed)?\b)", re.IGNORECASE)
APPROVAL_REJECTION_TERMS = (
    "不批准",
    "未批准",
    "不同意",
    "不通过",
    "未通过",
    "驳回",
    "不代表",
    "不是批准",
    "not approve",
    "not approved",
    "do not approve",
    "disapprove",
    "reject",
)
APPROVAL_META_TERMS = (
    "文档中",
    "文件中",
    "示例",
    "历史",
    "引用",
    "document says",
    "file says",
    "example",
    "historical",
    "quoted",
)
DEMO_TERMS = ("demo", "simulation", "simulate", "模拟", "演练", "预演")
DEMO_ACTION_TERMS = (
    "批准", "同意", "授权", "请", "运行", "进行", "做", "跑", "开始",
    "approve", "authorize", "run", "start",
)
DEMO_REJECTION_TERMS = APPROVAL_REJECTION_TERMS + (
    "不要", "不做", "不跑", "不重跑", "不用", "无需", "不需要", "别做", "别跑", "别重跑", "别运行", "别进行",
    "取消", "停止", "do not", "don't", "dont", "no demo", "without demo", "cancel", "stop",
)

DEFAULT_TEST_PATHS = (
    "**/src/test/**",
    "**/test/**",
    "**/tests/**",
    "**/*Test.java",
    "**/*Tests.java",
    "**/*Spec.java",
)

TRADITIONAL_ONLY_CHARS = frozenset(
    "體臺灣們後裏與為這個發現實驗證審總結檔歸單測試資訊處將應須讓開關門"
    "階轉態規則產項數據庫執務運維護優錯誤讀寫錄碼權戶組織報風險嚴級別範圍"
    "標準達過進還時會從對學習設計議問題說確認變據續終點線網絡節選擇"
)

FENCED_CODE_PATTERN = re.compile(r"```[^\n]*\n.*?```", re.DOTALL)
INLINE_CODE_PATTERN = re.compile(r"`[^`\n]+`")
STYLE_SCRIPT_PATTERN = re.compile(r"<(?:style|script)\b[^>]*>.*?</(?:style|script)>", re.IGNORECASE | re.DOTALL)
HTML_COMMENT_PATTERN = re.compile(r"<!--.*?-->", re.DOTALL)
HTML_TAG_PATTERN = re.compile(r"<[^>\n]+>")
URL_PATTERN = re.compile(r"https?://\S+")
MARKDOWN_LINK_TARGET_PATTERN = re.compile(r"\]\([^)]*\)")
PLACEHOLDER_PATTERN = re.compile(r"<[^>\n]+>")
MUSTACHE_PATTERN = re.compile(r"\{\{[^}\n]+\}\}")
HAN_PATTERN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
LATIN_WORD_PATTERN = re.compile(r"\b[A-Za-z][A-Za-z'-]*\b")


class ControlError(RuntimeError):
    """A deterministic control failure that must block workflow progress."""


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    if not path.is_file():
        raise ControlError(f"Required file does not exist: {path}")
    return sha256_bytes(path.read_bytes())


def human_readable_text(content: str) -> str:
    """Remove machine-oriented blocks before checking the human-readable body."""
    text = STYLE_SCRIPT_PATTERN.sub(" ", content)
    text = HTML_COMMENT_PATTERN.sub(" ", text)
    text = FENCED_CODE_PATTERN.sub(" ", text)
    text = INLINE_CODE_PATTERN.sub(" ", text)
    text = URL_PATTERN.sub(" ", text)
    text = MARKDOWN_LINK_TARGET_PATTERN.sub("]", text)
    text = PLACEHOLDER_PATTERN.sub(" ", text)
    text = MUSTACHE_PATTERN.sub(" ", text)
    text = HTML_TAG_PATTERN.sub(" ", text)
    return text


def simplified_chinese_body_issues(
    content: str,
    *,
    minimum_han: int = 16,
    enforce_dominance: bool = True,
) -> list[str]:
    """Return stable issue codes when human-readable prose is not Simplified-Chinese-led."""
    body = human_readable_text(content)
    han_count = len(HAN_PATTERN.findall(body))
    latin_word_count = len(LATIN_WORD_PATTERN.findall(body))
    issues: list[str] = []
    if han_count < minimum_han:
        issues.append(f"INSUFFICIENT_SIMPLIFIED_CHINESE:{han_count}<{minimum_han}")

    traditional = sorted(set(body) & TRADITIONAL_ONLY_CHARS)
    if traditional:
        issues.append("TRADITIONAL_CHINESE_DETECTED:" + "".join(traditional))

    if enforce_dominance and latin_word_count > han_count:
        issues.append(f"ENGLISH_DOMINATES_BODY:{latin_word_count}>{han_count}")

    if enforce_dominance:
        english_prose_lines: list[int] = []
        for line_number, line in enumerate(body.splitlines(), start=1):
            stripped = line.strip()
            if not stripped or "|" in stripped or HAN_PATTERN.search(stripped):
                continue
            if len(LATIN_WORD_PATTERN.findall(stripped)) >= 8:
                english_prose_lines.append(line_number)
        if english_prose_lines:
            rendered = ",".join(str(value) for value in english_prose_lines[:5])
            issues.append(f"ENGLISH_ONLY_PROSE_LINES:{rendered}")
    return issues


def validate_artifact_language(path: Path, stage: str) -> None:
    minimum_han = 8 if stage == "brief-design" else 16
    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise ControlError(
            f"ARTIFACT_LANGUAGE_NOT_SIMPLIFIED_CHINESE:{stage}:INVALID_UTF8"
        ) from exc
    issues = simplified_chinese_body_issues(content, minimum_han=minimum_han)
    if issues:
        raise ControlError(
            f"ARTIFACT_LANGUAGE_NOT_SIMPLIFIED_CHINESE:{stage}:" + ";".join(issues)
        )


def atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def atomic_write_bytes(path: Path, value: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(value)
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ControlError(f"Missing control file: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ControlError(f"Invalid JSON in {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ControlError(f"Expected JSON object in {path}")
    return value


def run_git(repo_root: Path, *args: str, check: bool = True) -> str:
    process = subprocess.run(
        ["git", *args],
        cwd=repo_root,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )
    if check and process.returncode != 0:
        detail = process.stderr.strip() or process.stdout.strip()
        raise ControlError(f"Git command failed ({' '.join(args)}): {detail}")
    return process.stdout.strip()


def git_root(path: Path) -> Path:
    root = run_git(path, "rev-parse", "--show-toplevel")
    return Path(root).resolve()


def git_path(repo_root: Path, name: str) -> Path:
    value = run_git(repo_root, "rev-parse", "--git-path", name)
    path = Path(value)
    return path if path.is_absolute() else (repo_root / path).resolve()


def git_hooks_path(repo_root: Path) -> Path:
    configured = run_git(
        repo_root,
        "config",
        "--path",
        "--get",
        "core.hooksPath",
        check=False,
    )
    if not configured:
        return git_path(repo_root, "hooks")
    path = Path(configured)
    return path if path.is_absolute() else (repo_root / path).resolve()


def git_guard_script(hook_name: str) -> bytes:
    original_name = f"{hook_name}.sdd2-original"
    script = f"""#!/bin/sh
{COMMIT_GUARD_MARKER}
active_lock="$(git rev-parse --git-path sdd2-active-feature.json 2>/dev/null)"
if [ -n "$active_lock" ] && [ -f "$active_lock" ]; then
  echo "SDD2_COMMIT_BLOCKED: 当前 worktree 存在未结束的 SDD2 Feature，禁止提交或推送。" >&2
  echo "请先完成或明确关闭当前 SDD2 Attempt；本 Skill 不会自动执行 git add、git commit 或 git push。" >&2
  exit 1
fi
hook_dir="$(dirname "$0")"
original_hook="$hook_dir/{original_name}"
if [ -x "$original_hook" ]; then
  exec "$original_hook" "$@"
fi
exit 0
"""
    return script.encode("utf-8")


def install_git_guards(repo_root: Path) -> list[str]:
    hooks_dir = git_hooks_path(repo_root)
    hooks_dir.mkdir(parents=True, exist_ok=True)
    installed: list[str] = []
    for hook_name in COMMIT_GUARD_HOOKS:
        hook = hooks_dir / hook_name
        backup = hooks_dir / f"{hook_name}.sdd2-original"
        if hook.is_file() and COMMIT_GUARD_MARKER in hook.read_text(encoding="utf-8", errors="replace"):
            hook.chmod(hook.stat().st_mode | 0o111)
            continue
        if hook.exists():
            if backup.exists():
                raise ControlError(
                    f"Cannot install SDD2 Git guard because both {hook} and {backup} exist"
                )
            os.replace(hook, backup)
        atomic_write_bytes(hook, git_guard_script(hook_name))
        hook.chmod(0o755)
        installed.append(hook_name)
    return installed


def repository_id(repo_root: Path) -> str:
    roots = sorted(run_git(repo_root, "rev-list", "--max-parents=0", "HEAD").splitlines())
    if not roots:
        raise ControlError("Cannot identify Git repository root commit")
    return sha256_bytes(canonical_json({"root_commits": roots}).encode("utf-8"))


def state_repo_root(feature_dir: Path, state: dict[str, Any]) -> Path:
    repo_root = git_root(feature_dir)
    expected = state.get("workspace_binding", {}).get("repository_id")
    if expected and expected != repository_id(repo_root):
        raise ControlError("Feature state belongs to a different Git repository")
    return repo_root


def scope_repo_root(feature_dir: Path, scope: dict[str, Any]) -> Path:
    repo_root = git_root(feature_dir)
    expected = scope.get("repository_id")
    if expected and expected != repository_id(repo_root):
        raise ControlError("Implementation scope belongs to a different Git repository")
    return repo_root


def feature_paths(feature_dir: Path) -> dict[str, Path]:
    control = feature_dir / CONTROL_DIR
    return {
        "control": control,
        "state": control / STATE_FILE,
        "approvals": control / APPROVAL_FILE,
        "events": control / EVENT_FILE,
        "scope": control / SCOPE_FILE,
        "unit_test_evidence": control / UNIT_TEST_EVIDENCE_FILE,
        "archive_evidence": control / ARCHIVE_EVIDENCE_FILE,
        "revisions": control / REVISION_DIR,
    }


def feature_location_errors(repo_root: Path, feature_dir: Path) -> list[str]:
    try:
        relative = feature_dir.relative_to(repo_root)
    except ValueError:
        return ["FEATURE_DIRECTORY_OUTSIDE_REPOSITORY"]
    parts = relative.parts
    if len(parts) != 3 or parts[0] != "sdd2-features":
        return [f"FEATURE_DIRECTORY_CONTRACT:{relative.as_posix()}"]
    return []


def feature_layout_errors(
    feature_dir: Path,
    state: dict[str, Any] | None,
    *,
    allow_unrecorded_stage: str | None = None,
) -> list[str]:
    recorded_stages = set() if state is None else set(state.get("artifacts", {}))
    allowed_stages = {"brief-design"} if state is None else set(recorded_stages)
    if state is not None:
        effective_action = state.get("next_required_action", "")
        block = state.get("blocked") or {}
        if block.get("code") == FEATURE_LAYOUT_BLOCK:
            effective_action = (
                block.get("resume_state") or {}
            ).get("next_required_action", effective_action)
        expected = NEXT_ACTION_ARTIFACT_STAGE.get(effective_action)
        if expected:
            allowed_stages.add(expected)
    if allow_unrecorded_stage:
        allowed_stages.add(allow_unrecorded_stage)

    allowed_directories = {
        CONTROL_DIR,
        f"{CONTROL_DIR}/{REVISION_DIR}",
        *(
            f"{CONTROL_DIR}/{REVISION_DIR}/{stage}"
            for stage in recorded_stages
        ),
    }
    allowed_control_files = {
        f"{CONTROL_DIR}/{filename}" for filename in ALWAYS_CONTROL_FILENAMES
    }
    if state is not None and state.get("implementation_permit") is not None:
        allowed_control_files.add(f"{CONTROL_DIR}/{SCOPE_FILE}")
    if state is not None and state.get("unit_test_execution") is not None:
        allowed_control_files.add(f"{CONTROL_DIR}/{UNIT_TEST_EVIDENCE_FILE}")
    if state is not None and (
        "archive" in recorded_stages
        or state.get("next_required_action") == "generate-archive-from-evidence"
    ):
        allowed_control_files.add(f"{CONTROL_DIR}/{ARCHIVE_EVIDENCE_FILE}")
    errors: list[str] = []
    revision_paths: dict[tuple[str, int], list[str]] = {}
    for path in sorted(feature_dir.rglob("*"), key=lambda item: item.as_posix()):
        relative = path.relative_to(feature_dir).as_posix()
        if path.is_symlink():
            errors.append(f"UNEXPECTED_FEATURE_SYMLINK:{relative}")
            continue
        if path.is_dir():
            if state is None or relative not in allowed_directories:
                errors.append(f"UNEXPECTED_FEATURE_DIRECTORY:{relative}")
            continue
        if not path.is_file():
            errors.append(f"UNEXPECTED_FEATURE_PATH_TYPE:{relative}")
            continue
        stage = ARTIFACT_STAGE_BY_FILENAME.get(relative)
        if stage:
            if stage not in allowed_stages:
                errors.append(f"UNEXPECTED_STAGE_ASSET:{relative}")
            continue
        if state is not None and relative in allowed_control_files:
            continue
        if (
            state is not None
            and relative.startswith(f"{CONTROL_DIR}/")
            and relative.rsplit("/", 1)[-1] in {
                SCOPE_FILE,
                UNIT_TEST_EVIDENCE_FILE,
                ARCHIVE_EVIDENCE_FILE,
            }
        ):
            errors.append(f"UNEXPECTED_CONTROL_FILE:{relative}")
            continue
        snapshot = REVISION_SNAPSHOT_PATTERN.fullmatch(relative)
        if state is not None and snapshot:
            stage = snapshot.group(1)
            revision = int(snapshot.group(2))
            digest = snapshot.group(3)
            artifact = state.get("artifacts", {}).get(stage)
            try:
                current_revision = (
                    int(artifact.get("revision", 0))
                    if isinstance(artifact, dict)
                    else 0
                )
            except (TypeError, ValueError):
                current_revision = 0
            if (
                artifact
                and revision >= 1
                and revision <= current_revision
                and sha256_file(path) == digest
            ):
                revision_paths.setdefault((stage, revision), []).append(relative)
                continue
            errors.append(f"UNEXPECTED_REVISION_SNAPSHOT:{relative}")
            continue
        errors.append(f"UNEXPECTED_FEATURE_FILE:{relative}")
    for (stage, revision), paths in revision_paths.items():
        if len(paths) > 1:
            errors.extend(
                f"DUPLICATE_REVISION_SNAPSHOT:{stage}:r{revision:04d}:{path}"
                for path in paths
            )
    return sorted(set(errors))


def normalize_feature_dir(value: str | Path) -> Path:
    path = Path(value).expanduser().resolve()
    if not path.is_dir():
        raise ControlError(f"Feature directory does not exist: {path}")
    return path


def load_state(feature_dir: Path) -> dict[str, Any]:
    state = read_json(feature_paths(feature_dir)["state"])
    if state.get("schema_version") != SCHEMA_VERSION:
        raise ControlError(
            f"Unsupported state schema: {state.get('schema_version')!r}; expected {SCHEMA_VERSION}"
        )
    repo_root = git_root(feature_dir)
    expected = feature_dir.relative_to(repo_root).as_posix()
    if state.get("feature_dir") != expected:
        raise ControlError(
            f"Feature directory binding mismatch: state={state.get('feature_dir')!r}, actual={expected!r}"
        )
    state_repo_root(feature_dir, state)
    return state


def save_state(feature_dir: Path, state: dict[str, Any]) -> None:
    state["updated_at"] = utc_now()
    atomic_write_json(feature_paths(feature_dir)["state"], state)


def persist_artifact_snapshot(
    feature_dir: Path,
    stage: str,
    revision: int,
    digest: str,
) -> str:
    source = feature_dir / ARTIFACT_FILES[stage]
    destination = feature_paths(feature_dir)["revisions"] / stage / f"r{revision:04d}-{digest}.md"
    content = source.read_bytes()
    if sha256_bytes(content) != digest:
        raise ControlError(f"Artifact changed while snapshotting: {source}")
    if destination.exists():
        if sha256_file(destination) != digest:
            raise ControlError(f"Immutable artifact snapshot collision: {destination}")
    else:
        atomic_write_bytes(destination, content)
    return destination.relative_to(feature_dir).as_posix()


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    records: list[dict[str, Any]] = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ControlError(f"Invalid JSONL at {path}:{number}: {exc}") from exc
        if not isinstance(value, dict):
            raise ControlError(f"Expected JSON object at {path}:{number}")
        records.append(value)
    return records


def validate_hash_chain(path: Path, hash_field: str) -> list[str]:
    errors: list[str] = []
    previous = None
    for index, record in enumerate(read_jsonl(path), 1):
        actual = record.get(hash_field)
        body = dict(record)
        body.pop(hash_field, None)
        expected = sha256_bytes(canonical_json(body).encode("utf-8"))
        if actual != expected:
            errors.append(f"{path.name}:{index} hash mismatch")
        if body.get("previous_hash") != previous:
            errors.append(f"{path.name}:{index} previous_hash mismatch")
        previous = actual
    return errors


def append_chained_record(path: Path, record: dict[str, Any], hash_field: str) -> dict[str, Any]:
    existing = read_jsonl(path)
    record = dict(record)
    record["previous_hash"] = existing[-1].get(hash_field) if existing else None
    record[hash_field] = sha256_bytes(canonical_json(record).encode("utf-8"))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(canonical_json(record) + "\n")
    return record


def state_projection_sha256(state: dict[str, Any]) -> str:
    payload = {
        key: value
        for key, value in state.items()
        if key != "updated_at"
    }
    return sha256_bytes(canonical_json(payload).encode("utf-8"))


def state_event_projection_errors(feature_dir: Path, state: dict[str, Any]) -> list[str]:
    events = read_jsonl(feature_paths(feature_dir)["events"])
    if not events:
        return ["STATE_EVENT_HISTORY_MISSING"]
    latest = events[-1]
    expected = latest.get("state_sha256")
    if expected is None:
        return []
    errors: list[str] = []
    if expected != state_projection_sha256(state):
        errors.append("STATE_EVENT_PROJECTION_MISMATCH")
    if latest.get("feature_id") != state.get("feature_id"):
        errors.append("STATE_EVENT_FEATURE_MISMATCH")
    if latest.get("attempt") != state.get("attempt"):
        errors.append("STATE_EVENT_ATTEMPT_MISMATCH")
    if latest.get("revision") != state.get("revision"):
        errors.append("STATE_EVENT_REVISION_MISMATCH")
    return errors


def append_event(feature_dir: Path, state: dict[str, Any], event_type: str, payload: dict[str, Any]) -> None:
    append_chained_record(
        feature_paths(feature_dir)["events"],
        {
            "event_id": str(uuid.uuid4()),
            "timestamp": utc_now(),
            "event_type": event_type,
            "feature_id": state["feature_id"],
            "attempt": state["attempt"],
            "revision": state["revision"],
            "payload": payload,
            "state_sha256": state_projection_sha256(state),
        },
        "event_hash",
    )


def lock_path(repo_root: Path) -> Path:
    return git_path(repo_root, "sdd2-active-feature.json")


def acquire_lock(repo_root: Path, feature_dir: Path, feature_id: str) -> None:
    path = lock_path(repo_root)
    feature_repo_path = feature_dir.relative_to(repo_root).as_posix()
    if path.exists():
        current = read_json(path)
        if current.get("feature_dir") != feature_repo_path:
            raise ControlError(
                "This Git worktree is locked by another SDD2 feature: "
                f"{current.get('feature_id')} at {current.get('feature_dir')}. "
                "Use a separate Git worktree for parallel features."
            )
        return
    atomic_write_json(
        path,
        {
            "schema_version": SCHEMA_VERSION,
            "feature_id": feature_id,
            "feature_dir": feature_repo_path,
            "repository_id": repository_id(repo_root),
            "acquired_at": utc_now(),
        },
    )


def release_lock(repo_root: Path, feature_dir: Path, feature_id: str) -> None:
    path = lock_path(repo_root)
    if not path.exists():
        return
    current = read_json(path)
    feature_repo_path = feature_dir.relative_to(repo_root).as_posix()
    if current.get("feature_dir") != feature_repo_path or current.get("feature_id") != feature_id:
        raise ControlError("Cannot release a worktree lock owned by another SDD2 feature")
    path.unlink()


def verify_lock(feature_dir: Path, state: dict[str, Any]) -> list[str]:
    if state.get("execution_mode") == "historical-example" or state.get("stage_status") in TERMINAL_STATUSES:
        return []
    repo_root = state_repo_root(feature_dir, state)
    path = lock_path(repo_root)
    if not path.exists():
        return ["FEATURE_LOCK_MISSING"]
    current = read_json(path)
    if current.get("feature_dir") != state["feature_dir"]:
        return ["FEATURE_LOCK_MISMATCH"]
    if current.get("feature_id") != state["feature_id"]:
        return ["FEATURE_LOCK_ID_MISMATCH"]
    if current.get("repository_id") != repository_id(repo_root):
        return ["FEATURE_LOCK_REPOSITORY_MISMATCH"]
    return []


def artifact_key_for_stage(stage: str) -> str:
    if stage not in ARTIFACT_FILES:
        raise ControlError(f"Unknown artifact stage: {stage}")
    return stage


def workflow_stage_for_artifact(stage: str) -> str:
    return {
        "code-review-findings": "code-review",
        "auto-fix-summary": "auto-fix",
    }.get(stage, stage)


def stage_index(stage: str) -> int:
    normalized = "unit-test-summary" if stage == "unit-test" else stage
    try:
        return STAGE_ORDER.index(normalized)
    except ValueError as exc:
        raise ControlError(f"Unknown workflow stage: {stage}") from exc


def invalidate_from(
    state: dict[str, Any],
    changed_stage: str,
    reason: str,
) -> list[str]:
    changed_index = stage_index(changed_stage)
    invalidated: list[str] = []
    for stage, approval in state.get("approvals", {}).items():
        if approval.get("status") == "approved" and stage_index(stage) >= changed_index:
            approval["status"] = "invalidated"
            approval["invalidated_reason"] = reason
            invalidated.append(f"approval:{stage}")
    gate_stage = {"code-review": "code-review", "auto-fix": "auto-fix", "unit-test": "unit-test-summary"}
    for gate, result in state.get("quality_gates", {}).items():
        if result.get("status") not in {"invalidated", "not-recorded"} and stage_index(gate_stage[gate]) >= changed_index:
            result["status"] = "invalidated"
            result["invalidated_reason"] = reason
            invalidated.append(f"quality:{gate}")
    for phase, review in state.get("phase_reviews", {}).items():
        if changed_index <= stage_index("tasks") and review.get("status") == "approved":
            review["status"] = "invalidated"
            review["invalidated_reason"] = reason
            invalidated.append(f"phase:{phase}")
    if invalidated:
        state.setdefault("invalidations", []).append(
            {
                "timestamp": utc_now(),
                "changed_stage": changed_stage,
                "reason": reason,
                "invalidated": invalidated,
            }
        )
    return invalidated


def direct_approval(text: str, stage_terms: Iterable[str]) -> bool:
    lowered = text.strip().lower()
    if any(term in lowered for term in APPROVAL_REJECTION_TERMS + APPROVAL_META_TERMS):
        return False
    return bool(APPROVAL_PATTERN.search(lowered)) and any(term.lower() in lowered for term in stage_terms)


def explicit_approval(stage: str, text: str) -> bool:
    return direct_approval(text, STAGE_WORDS[stage])


def unique_in_order(values: Iterable[str]) -> list[str]:
    return list(dict.fromkeys(values))


def current_artifact_hash(feature_dir: Path, stage: str) -> str:
    filename = ARTIFACT_FILES[artifact_key_for_stage(stage)]
    return sha256_file(feature_dir / filename)


def artifact_drift(feature_dir: Path, state: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    for stage, record in state.get("artifacts", {}).items():
        path = feature_dir / record["path"]
        if not path.is_file():
            errors.append(f"ARTIFACT_MISSING:{stage}:{record['path']}")
            continue
        actual = sha256_file(path)
        if actual != record.get("sha256"):
            errors.append(f"ARTIFACT_DRIFT:{stage}:{record['path']}")
        snapshot_path = record.get("snapshot_path")
        if not snapshot_path:
            if state.get("execution_mode") != "historical-example":
                errors.append(f"ARTIFACT_SNAPSHOT_MISSING:{stage}")
            continue
        snapshot = feature_dir / snapshot_path
        if not snapshot.is_file():
            errors.append(f"ARTIFACT_SNAPSHOT_FILE_MISSING:{stage}:{snapshot_path}")
        elif sha256_file(snapshot) != record.get("sha256"):
            errors.append(f"ARTIFACT_SNAPSHOT_DRIFT:{stage}:{snapshot_path}")
    return errors


def changed_paths(repo_root: Path, base_commit: str) -> list[str]:
    tracked = run_git(repo_root, "diff", "--name-only", "-z", base_commit)
    untracked = run_git(repo_root, "ls-files", "--others", "--exclude-standard", "-z")
    paths = {value for value in tracked.split("\0") if value}
    paths.update(value for value in untracked.split("\0") if value)
    return sorted(paths)


def uncontrolled_sibling_feature_errors(
    repo_root: Path,
    feature_repo_path: str,
) -> list[str]:
    head_commit = run_git(repo_root, "rev-parse", "HEAD")
    current_prefix = feature_repo_path.rstrip("/") + "/"
    active_feature_dir: str | None = None
    current_lock = lock_path(repo_root)
    if current_lock.is_file():
        try:
            active_feature_dir = read_json(current_lock).get("feature_dir")
        except ControlError:
            active_feature_dir = None
    sibling_roots: set[str] = set()
    for relative in changed_paths(repo_root, head_commit):
        if relative == feature_repo_path or relative.startswith(current_prefix):
            continue
        parts = relative.split("/")
        if len(parts) < 3 or parts[0] != "sdd2-features":
            continue
        sibling_roots.add("/".join(parts[:3]))

    errors: list[str] = []
    for sibling_root in sorted(sibling_roots):
        if sibling_root == active_feature_dir:
            continue
        sibling_state_path = repo_root / sibling_root / CONTROL_DIR / STATE_FILE
        try:
            sibling_state = read_json(sibling_state_path)
        except ControlError:
            sibling_state = None
        if (
            isinstance(sibling_state, dict)
            and sibling_state.get("stage_status") in TERMINAL_STATUSES
        ):
            continue
        errors.append(f"UNCONTROLLED_SIBLING_FEATURE:{sibling_root}")
    return errors


def feature_generation_errors(
    feature_dir: Path,
    state: dict[str, Any],
    *,
    allow_unrecorded_stage: str | None = None,
) -> list[str]:
    if state.get("execution_mode") == "historical-example":
        return []
    repo_root = state_repo_root(feature_dir, state)
    errors = feature_location_errors(repo_root, feature_dir)
    errors.extend(
        feature_layout_errors(
            feature_dir,
            state,
            allow_unrecorded_stage=allow_unrecorded_stage,
        )
    )
    errors.extend(
        uncontrolled_sibling_feature_errors(
            repo_root,
            state["feature_repo_path"],
        )
    )
    return sorted(set(errors))


def planning_snapshot(repo_root: Path, feature_repo_path: str) -> dict[str, Any]:
    head_commit = run_git(repo_root, "rev-parse", "HEAD")
    feature_prefix = feature_repo_path.rstrip("/") + "/"
    files: list[dict[str, str]] = []
    for relative in changed_paths(repo_root, head_commit):
        if relative == feature_repo_path or relative.startswith(feature_prefix):
            continue
        path = repo_root / relative
        files.append(
            {
                "path": relative,
                "sha256": sha256_file(path) if path.is_file() else "<deleted>",
            }
        )
    payload = {
        "branch": run_git(repo_root, "branch", "--show-current"),
        "head_commit": head_commit,
        "head_tree": run_git(repo_root, "rev-parse", "HEAD^{tree}"),
        "files": files,
    }
    return {
        "captured_at": utc_now(),
        **payload,
        "snapshot_sha256": sha256_bytes(canonical_json(payload).encode("utf-8")),
    }


def planning_guard_errors(feature_dir: Path, state: dict[str, Any]) -> list[str]:
    if (
        state.get("execution_mode") == "historical-example"
        or state.get("stage_status") in TERMINAL_STATUSES
        or state.get("implementation_started") is True
        or state.get("implementation_permit") is not None
    ):
        return []
    baseline = state.get("planning_baseline")
    if not isinstance(baseline, dict):
        return ["PLANNING_BASELINE_MISSING"]
    current = planning_snapshot(
        state_repo_root(feature_dir, state),
        state["feature_repo_path"],
    )
    errors: list[str] = []
    if current["branch"] != baseline.get("branch"):
        errors.append(
            f"PRE_IMPLEMENTATION_BRANCH_CHANGE:{baseline.get('branch')}->{current['branch'] or '<detached>'}"
        )
    if current["head_commit"] != baseline.get("head_commit"):
        errors.append(
            f"PRE_IMPLEMENTATION_GIT_HEAD_CHANGE:{baseline.get('head_commit')}->{current['head_commit']}"
        )
    baseline_files = {
        item["path"]: item["sha256"] for item in baseline.get("files", [])
    }
    current_files = {
        item["path"]: item["sha256"] for item in current.get("files", [])
    }
    for path in sorted(set(baseline_files) | set(current_files)):
        if baseline_files.get(path) != current_files.get(path):
            errors.append(f"PRE_IMPLEMENTATION_CHANGE:{path}")
    if (
        not errors
        and current["snapshot_sha256"] != baseline.get("snapshot_sha256")
    ):
        errors.append("PRE_IMPLEMENTATION_SNAPSHOT_MISMATCH")
    return errors


def block_premature_implementation_change(
    feature_dir: Path,
    state: dict[str, Any],
    errors: list[str],
) -> None:
    current_block = state.get("blocked") or {}
    if current_block.get("code") == PREMATURE_CHANGE_BLOCK:
        return
    resume_state = {
        "current_stage": state["current_stage"],
        "stage_status": state["stage_status"],
        "next_required_action": state["next_required_action"],
    }
    state["blocked"] = {
        "code": PREMATURE_CHANGE_BLOCK,
        "reason": ", ".join(errors),
        "recovery": "撤销或移走所有提前产生的代码、测试、配置和 Git 提交，然后再次恢复当前 Gate。",
        "resume_state": resume_state,
    }
    state["stage_status"] = "blocked"
    state["next_required_action"] = "restore-planning-baseline-before-current-gate"
    state["revision"] += 1
    append_event(
        feature_dir,
        state,
        "premature-implementation-blocked",
        {"errors": errors, "resume_state": resume_state},
    )
    save_state(feature_dir, state)


def restore_premature_change_block(feature_dir: Path, state: dict[str, Any]) -> None:
    block = state.get("blocked") or {}
    if block.get("code") != PREMATURE_CHANGE_BLOCK:
        return
    resume_state = block.get("resume_state") or {}
    required = {"current_stage", "stage_status", "next_required_action"}
    if not required.issubset(resume_state):
        raise ControlError("PREMATURE_IMPLEMENTATION_BLOCK_RESUME_STATE_MISSING")
    state["current_stage"] = resume_state["current_stage"]
    state["stage_status"] = resume_state["stage_status"]
    state["next_required_action"] = resume_state["next_required_action"]
    state["blocked"] = None
    state["revision"] += 1
    append_event(
        feature_dir,
        state,
        "premature-implementation-restored",
        {"restored": resume_state},
    )
    save_state(feature_dir, state)


def block_unexpected_feature_layout(
    feature_dir: Path,
    state: dict[str, Any],
    errors: list[str],
) -> None:
    current_block = state.get("blocked") or {}
    if current_block.get("code") == FEATURE_LAYOUT_BLOCK:
        return
    resume_state = {
        "current_stage": state["current_stage"],
        "stage_status": state["stage_status"],
        "next_required_action": state["next_required_action"],
        "blocked": state.get("blocked"),
    }
    state["blocked"] = {
        "code": FEATURE_LAYOUT_BLOCK,
        "reason": ", ".join(errors),
        "recovery": "移走或删除白名单外文件及重复 Feature 目录，然后再次恢复；不得把额外文件追认为流程资产。",
        "resume_state": resume_state,
    }
    state["stage_status"] = "blocked"
    state["next_required_action"] = "remove-unexpected-feature-paths-before-current-action"
    state["revision"] += 1
    append_event(
        feature_dir,
        state,
        "unexpected-feature-layout-blocked",
        {"errors": errors, "resume_state": resume_state},
    )
    save_state(feature_dir, state)


def restore_unexpected_feature_layout_block(
    feature_dir: Path,
    state: dict[str, Any],
) -> None:
    block = state.get("blocked") or {}
    if block.get("code") != FEATURE_LAYOUT_BLOCK:
        return
    resume_state = block.get("resume_state") or {}
    required = {
        "current_stage",
        "stage_status",
        "next_required_action",
        "blocked",
    }
    if not required.issubset(resume_state):
        raise ControlError("UNEXPECTED_FEATURE_LAYOUT_RESUME_STATE_MISSING")
    state["current_stage"] = resume_state["current_stage"]
    state["stage_status"] = resume_state["stage_status"]
    state["next_required_action"] = resume_state["next_required_action"]
    state["blocked"] = resume_state["blocked"]
    state["revision"] += 1
    append_event(
        feature_dir,
        state,
        "unexpected-feature-layout-restored",
        {"restored": resume_state},
    )
    save_state(feature_dir, state)


def path_matches(path: str, patterns: Iterable[str]) -> bool:
    return any(path == pattern or fnmatch.fnmatchcase(path, pattern) for pattern in patterns)


def reject_unsafe_patterns(patterns: Iterable[str]) -> None:
    unsafe = {"", ".", "./", "*", "**", "**/*", "/"}
    bad = [pattern for pattern in patterns if pattern.strip() in unsafe or Path(pattern).is_absolute()]
    if bad:
        raise ControlError(f"Unsafe or overly broad scope pattern(s): {', '.join(bad)}")


def snapshot_for_scope(repo_root: Path, scope: dict[str, Any]) -> dict[str, Any]:
    base_commit = scope["base_commit"]
    feature_prefix = scope["feature_repo_path"].rstrip("/") + "/"
    files: list[dict[str, str]] = []
    violations: list[str] = []
    current_branch = run_git(repo_root, "branch", "--show-current")
    if current_branch != scope["branch"]:
        violations.append(f"BRANCH_MISMATCH:{current_branch or '<detached>'}")
    for relative in changed_paths(repo_root, base_commit):
        if relative == scope["feature_repo_path"] or relative.startswith(feature_prefix):
            continue
        if path_matches(relative, scope.get("forbidden_paths", [])):
            violations.append(f"FORBIDDEN_PATH:{relative}")
            continue
        if not path_matches(relative, scope["allowed_paths"]):
            violations.append(f"OUT_OF_SCOPE:{relative}")
            continue
        path = repo_root / relative
        digest = sha256_file(path) if path.is_file() else "<deleted>"
        files.append({"path": relative, "sha256": digest})
    payload = {
        "base_commit": base_commit,
        "branch": scope["branch"],
        "head_commit": run_git(repo_root, "rev-parse", "HEAD"),
        "head_tree": run_git(repo_root, "rev-parse", "HEAD^{tree}"),
        "files": files,
    }
    return {
        "captured_at": utc_now(),
        "files": files,
        "head_commit": payload["head_commit"],
        "head_tree": payload["head_tree"],
        "snapshot_sha256": sha256_bytes(canonical_json(payload).encode("utf-8")),
        "violations": violations,
    }


def changed_test_paths(scope: dict[str, Any], snapshot: dict[str, Any]) -> list[str]:
    patterns = scope.get("test_path_patterns") or list(DEFAULT_TEST_PATHS)
    return sorted(
        item["path"]
        for item in snapshot.get("files", [])
        if item.get("sha256") != "<deleted>"
        and path_matches(item["path"], patterns)
    )


def test_command_kind(command: list[str]) -> str:
    if not command:
        raise ControlError("Unit Test execution requires a test command after --")
    if any("\x00" in value or "\n" in value for value in command):
        raise ControlError("Unit Test command contains an invalid argument")
    executable = Path(command[0]).name.lower()
    arguments = [value.lower() for value in command[1:]]
    if executable.startswith("python"):
        if len(arguments) >= 2 and arguments[0] == "-m" and arguments[1] in {"unittest", "pytest"}:
            return f"python-{arguments[1]}"
    elif executable in {"pytest", "py.test"}:
        return "pytest"
    elif executable in {"mvn", "mvnw"}:
        if (
            "test" in arguments
            and not any(
                value in {"-dskiptests", "-dmaven.test.skip=true"}
                or value.startswith("-dskiptests=")
                for value in arguments
            )
        ):
            return "maven-test"
    elif executable in {"gradle", "gradlew"}:
        if (
            any(value == "test" or value.endswith(":test") for value in arguments)
            and not any(
                arguments[index : index + 2] == ["-x", "test"]
                for index in range(max(0, len(arguments) - 1))
            )
        ):
            return "gradle-test"
    elif executable in {"npm", "pnpm", "yarn", "bun"}:
        if "test" in arguments:
            return f"{executable}-test"
    elif executable == "dotnet" and arguments and arguments[0] == "test":
        return "dotnet-test"
    elif executable == "go" and arguments and arguments[0] == "test":
        return "go-test"
    elif executable == "cargo" and arguments and arguments[0] == "test":
        return "cargo-test"
    raise ControlError(
        "Unsupported or non-test command. Use a recognized test runner without shell wrappers or skip-test flags."
    )


def parsed_test_counts(stdout: str, stderr: str) -> dict[str, Any]:
    output = f"{stdout}\n{stderr}"

    maven = re.findall(
        r"Tests run:\s*(\d+),\s*Failures:\s*(\d+),\s*Errors:\s*(\d+),\s*Skipped:\s*(\d+)",
        output,
        re.IGNORECASE,
    )
    if maven:
        total, failed, errors, skipped = (int(value) for value in maven[-1])
        return {
            "total": total,
            "passed": max(0, total - failed - errors - skipped),
            "failed": failed,
            "errors": errors,
            "skipped": skipped,
            "source": "maven-surefire-output",
        }

    unittest_match = re.search(r"Ran\s+(\d+)\s+tests?", output, re.IGNORECASE)
    if unittest_match:
        total = int(unittest_match.group(1))
        failed = 0
        errors = 0
        skipped = 0
        failed_match = re.search(r"FAILED\s*\(([^)]*)\)", output, re.IGNORECASE)
        if failed_match:
            values = {
                key.lower(): int(value)
                for key, value in re.findall(
                    r"(failures|errors|skipped)\s*=\s*(\d+)",
                    failed_match.group(1),
                    re.IGNORECASE,
                )
            }
            failed = values.get("failures", 0)
            errors = values.get("errors", 0)
            skipped = values.get("skipped", 0)
        else:
            skipped_match = re.search(r"OK\s*\(\s*skipped\s*=\s*(\d+)\s*\)", output, re.IGNORECASE)
            if skipped_match:
                skipped = int(skipped_match.group(1))
        return {
            "total": total,
            "passed": max(0, total - failed - errors - skipped),
            "failed": failed,
            "errors": errors,
            "skipped": skipped,
            "source": "python-unittest-output",
        }

    pytest_lines = [
        line
        for line in output.splitlines()
        if re.search(r"\b(?:passed|failed|error|errors|skipped)\b", line, re.IGNORECASE)
    ]
    if pytest_lines:
        summary = pytest_lines[-1]
        values = {
            label.lower(): int(value)
            for value, label in re.findall(
                r"(\d+)\s+(passed|failed|errors?|skipped)",
                summary,
                re.IGNORECASE,
            )
        }
        if values:
            passed = values.get("passed", 0)
            failed = values.get("failed", 0)
            errors = values.get("error", 0) + values.get("errors", 0)
            skipped = values.get("skipped", 0)
            return {
                "total": passed + failed + errors + skipped,
                "passed": passed,
                "failed": failed,
                "errors": errors,
                "skipped": skipped,
                "source": "pytest-output",
            }

    cargo = re.findall(
        r"test result:\s*\w+\.\s*(\d+)\s+passed;\s*(\d+)\s+failed;\s*(\d+)\s+ignored",
        output,
        re.IGNORECASE,
    )
    if cargo:
        passed = sum(int(item[0]) for item in cargo)
        failed = sum(int(item[1]) for item in cargo)
        skipped = sum(int(item[2]) for item in cargo)
        return {
            "total": passed + failed + skipped,
            "passed": passed,
            "failed": failed,
            "errors": 0,
            "skipped": skipped,
            "source": "cargo-output",
        }

    jest = re.findall(
        r"Tests:\s*(?:(\d+)\s+failed,\s*)?(?:(\d+)\s+skipped,\s*)?(\d+)\s+passed,\s*(\d+)\s+total",
        output,
        re.IGNORECASE,
    )
    if jest:
        failed, skipped, passed, total = jest[-1]
        return {
            "total": int(total),
            "passed": int(passed),
            "failed": int(failed or 0),
            "errors": 0,
            "skipped": int(skipped or 0),
            "source": "jest-output",
        }

    return {
        "total": 0,
        "passed": 0,
        "failed": 0,
        "errors": 0,
        "skipped": 0,
        "source": "unverified",
    }


def bounded_output(value: str, limit: int = 8000) -> str:
    if len(value) <= limit:
        return value
    half = limit // 2
    return value[:half] + "\n...[output truncated by SDD2 controller]...\n" + value[-half:]


def unit_test_execution_errors(
    feature_dir: Path,
    state: dict[str, Any],
    required_outcome: str | None = None,
) -> list[str]:
    projection = state.get("unit_test_execution")
    if not isinstance(projection, dict):
        return ["UNIT_TEST_EXECUTION_MISSING"]
    path = feature_paths(feature_dir)["unit_test_evidence"]
    if not path.is_file():
        return ["UNIT_TEST_EVIDENCE_FILE_MISSING"]
    try:
        evidence = read_json(path)
    except ControlError:
        return ["UNIT_TEST_EVIDENCE_INVALID"]
    if not isinstance(evidence, dict):
        return ["UNIT_TEST_EVIDENCE_INVALID"]
    body = dict(evidence)
    actual_hash = body.pop("evidence_sha256", None)
    expected_hash = sha256_bytes(canonical_json(body).encode("utf-8"))
    errors: list[str] = []
    if actual_hash != expected_hash:
        errors.append("UNIT_TEST_EVIDENCE_HASH_MISMATCH")
    expected = {
        "feature_id": state.get("feature_id"),
        "attempt": state.get("attempt"),
        "evidence_sha256": actual_hash,
        "scope_sha256": evidence.get("scope_sha256"),
        "code_revision": evidence.get("code_revision"),
        "outcome": evidence.get("outcome"),
    }
    for field, value in expected.items():
        if projection.get(field) != value:
            errors.append(f"UNIT_TEST_STATE_EVIDENCE_MISMATCH:{field}")
    try:
        scope = load_scope(feature_dir)
        frozen = scope.get("frozen_snapshot") or {}
        expected_paths = changed_test_paths(scope, frozen)
        expected_sources = [
            item
            for item in frozen.get("files", [])
            if item.get("path") in expected_paths
        ]
        if evidence.get("scope_sha256") != frozen.get("snapshot_sha256"):
            errors.append("UNIT_TEST_EVIDENCE_SCOPE_MISMATCH")
        if evidence.get("changed_test_paths") != expected_paths:
            errors.append("UNIT_TEST_EVIDENCE_TEST_PATH_MISMATCH")
        if evidence.get("changed_test_sources") != expected_sources:
            errors.append("UNIT_TEST_EVIDENCE_TEST_SOURCE_HASH_MISMATCH")
    except (ControlError, KeyError, TypeError, ValueError):
        errors.append("UNIT_TEST_EVIDENCE_SCOPE_INVALID")
    if required_outcome and evidence.get("outcome") != required_outcome:
        errors.append(
            f"UNIT_TEST_OBSERVED_OUTCOME_MISMATCH:{evidence.get('outcome')}!={required_outcome}"
        )
    counts = evidence.get("test_counts")
    if not isinstance(counts, dict):
        errors.append("UNIT_TEST_COUNTS_MISSING")
        counts = {}
    if evidence.get("outcome") == "passed":
        if evidence.get("exit_code") != 0:
            errors.append("UNIT_TEST_PASSED_WITH_NONZERO_EXIT")
        if counts.get("total", 0) <= 0 or counts.get("passed", 0) <= 0:
            errors.append("UNIT_TEST_PASSED_WITHOUT_OBSERVED_TEST")
        if counts.get("failed", 0) or counts.get("errors", 0):
            errors.append("UNIT_TEST_PASSED_WITH_FAILURES")
        if evidence.get("scope_changed_during_test") is not False:
            errors.append("UNIT_TEST_PASSED_WITH_SCOPE_CHANGE")
    return errors


def load_scope(feature_dir: Path) -> dict[str, Any]:
    return read_json(feature_paths(feature_dir)["scope"])


def scope_drift(feature_dir: Path, state: dict[str, Any]) -> list[str]:
    scope_path = feature_paths(feature_dir)["scope"]
    if not scope_path.exists():
        if (
            stage_index(state["current_stage"]) >= stage_index("implementation")
            and state.get("next_required_action") != "capture-implementation-scope"
        ):
            return ["SCOPE_MANIFEST_MISSING"]
        return []
    try:
        scope = load_scope(feature_dir)
        snapshot = snapshot_for_scope(scope_repo_root(feature_dir, scope), scope)
    except (ControlError, KeyError, TypeError, ValueError):
        return ["SCOPE_MANIFEST_INVALID"]
    if snapshot["violations"]:
        return snapshot["violations"]
    frozen = scope.get("frozen_snapshot")
    if frozen and frozen.get("snapshot_sha256") != snapshot["snapshot_sha256"]:
        return ["IMPLEMENTATION_SCOPE_DRIFT"]
    return []


def approval_record_binding_errors(
    feature_dir: Path,
    state: dict[str, Any],
    stage: str,
    approval: dict[str, Any],
) -> list[str]:
    approval_id = approval.get("approval_id")
    records = read_jsonl(feature_paths(feature_dir)["approvals"])
    matches = [
        record
        for record in records
        if record.get("approval_id") == approval_id
    ]
    if len(matches) != 1:
        code = "MISSING" if not matches else "DUPLICATED"
        return [f"APPROVAL_CHAIN_RECORD_{code}:{stage}"]
    record = matches[0]
    expected = {
        "feature_id": state.get("feature_id"),
        "stage": stage,
        "result": "approved",
        "attempt": approval.get("attempt"),
        "artifact_revision": approval.get("artifact_revision"),
        "artifact_sha256": approval.get("artifact_sha256"),
        "record_hash": approval.get("record_hash"),
    }
    return [
        f"APPROVAL_CHAIN_BINDING_MISMATCH:{stage}:{field}"
        for field, value in expected.items()
        if record.get(field) != value
    ]


def phase_review_record_binding_errors(
    feature_dir: Path,
    state: dict[str, Any],
    phase: str,
    review: dict[str, Any],
) -> list[str]:
    errors: list[str] = []
    approval_id = review.get("approval_id")
    if approval_id:
        projection = {
            "approval_id": approval_id,
            "attempt": review.get("attempt"),
            "artifact_revision": review.get("tasks_revision"),
            "artifact_sha256": review.get("tasks_sha256"),
            "record_hash": review.get("record_hash"),
        }
        errors.extend(
            approval_record_binding_errors(
                feature_dir,
                state,
                f"phase-review:{phase}",
                projection,
            )
        )
        return errors

    legacy_matches = [
        event
        for event in read_jsonl(feature_paths(feature_dir)["events"])
        if event.get("event_type") == "phase-approved"
        and event.get("attempt") == state.get("attempt")
        and event.get("payload", {}).get("phase") == phase
        and event.get("payload", {}).get("source") == review.get("source")
        and event.get("payload", {}).get("approver_role") == review.get("approver_role")
    ]
    if not legacy_matches:
        errors.append(f"PHASE_REVIEW_APPROVAL_CHAIN_MISSING:{phase}")
    return errors


def approval_projection_errors(feature_dir: Path, state: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    for stage, approval in state.get("approvals", {}).items():
        if not isinstance(approval, dict):
            errors.append(f"APPROVAL_STATE_INVALID:{stage}")
            continue
        errors.extend(
            approval_record_binding_errors(feature_dir, state, stage, approval)
        )
    for phase, review in state.get("phase_reviews", {}).items():
        if not isinstance(review, dict):
            errors.append(f"PHASE_REVIEW_STATE_INVALID:{phase}")
            continue
        errors.extend(
            phase_review_record_binding_errors(
                feature_dir,
                state,
                phase,
                review,
            )
        )
    return errors


def phase_review_errors(
    feature_dir: Path,
    state: dict[str, Any],
    phase: str,
) -> list[str]:
    review = state.get("phase_reviews", {}).get(phase)
    if not isinstance(review, dict) or review.get("status") != "approved":
        return [f"PHASE_REVIEW_NOT_APPROVED:{phase}"]
    errors = phase_review_record_binding_errors(
        feature_dir,
        state,
        phase,
        review,
    )
    if review.get("tasks_revision") != state.get("artifacts", {}).get("tasks", {}).get("revision"):
        errors.append(f"PHASE_REVIEW_TASKS_REVISION_MISMATCH:{phase}")
    if review.get("tasks_sha256") != state.get("artifacts", {}).get("tasks", {}).get("sha256"):
        errors.append(f"PHASE_REVIEW_TASKS_HASH_MISMATCH:{phase}")
    return errors


def approval_errors(feature_dir: Path, state: dict[str, Any], stage: str) -> list[str]:
    approval = state.get("approvals", {}).get(stage)
    artifact = state.get("artifacts", {}).get(stage)
    if not approval or approval.get("status") != "approved":
        return [f"APPROVAL_MISSING_OR_INVALID:{stage}"]
    if not artifact:
        return [f"APPROVED_ARTIFACT_MISSING:{stage}"]
    errors = []
    if approval.get("attempt") != state.get("attempt"):
        errors.append(f"APPROVAL_ATTEMPT_MISMATCH:{stage}")
    if approval.get("artifact_sha256") != artifact.get("sha256"):
        errors.append(f"APPROVAL_HASH_MISMATCH:{stage}")
    if approval.get("artifact_revision") != artifact.get("revision"):
        errors.append(f"APPROVAL_REVISION_MISMATCH:{stage}")
    actual = current_artifact_hash(feature_dir, stage)
    if actual != approval.get("artifact_sha256"):
        errors.append(f"APPROVAL_ARTIFACT_DRIFT:{stage}")
    errors.extend(
        approval_record_binding_errors(feature_dir, state, stage, approval)
    )
    return errors


def state_transition_errors(state: dict[str, Any]) -> list[str]:
    stage = state.get("current_stage")
    status = state.get("stage_status")
    action = state.get("next_required_action")
    blocked = state.get("blocked")
    errors: list[str] = []

    if status == "blocked":
        if not isinstance(blocked, dict) or not blocked.get("code"):
            return ["BLOCKED_STATE_REASON_MISSING"]
        expected_by_code = {
            PREMATURE_CHANGE_BLOCK: "restore-planning-baseline-before-current-gate",
            FEATURE_LAYOUT_BLOCK: "remove-unexpected-feature-paths-before-current-action",
            "IMPLEMENTATION_SCOPE_VIOLATION": "resolve-scope-violation",
            "CODE_REVIEW_BLOCKED": "resolve-code-review",
            "AUTO_FIX_FAILED": "resolve-auto-fix",
            "AUTO_FIX_BLOCKED": "resolve-auto-fix",
            "UNIT_TEST_FAILED": "resolve-unit-test",
            "UNIT_TEST_BLOCKED": "resolve-unit-test",
            "UNIT_TEST_NOT_RUN": "resolve-unit-test",
            "UNIT_TEST_SCOPE_CHANGED": "resolve-unit-test",
        }
        expected = expected_by_code.get(blocked.get("code"))
        if expected is None:
            errors.append(f"UNKNOWN_BLOCKED_STATE:{blocked.get('code')}")
        elif action != expected:
            errors.append("BLOCKED_NEXT_ACTION_MISMATCH")
        return errors

    if status in TERMINAL_STATUSES:
        terminal_actions = {
            "completed": ("archive", "none"),
            "closed-with-risk": ("archive", "none"),
            "aborted": ("archive", "none"),
            "superseded": ("archive", "none-historical-example"),
        }
        if terminal_actions.get(status) != (stage, action):
            errors.append("TERMINAL_STATE_TRANSITION_MISMATCH")
        return errors

    if blocked is not None:
        errors.append("BLOCK_REASON_PRESENT_OUTSIDE_BLOCKED_STATE")

    valid_static = {
        ("proposal-input", "ready", "assemble-proposal-input"),
        ("spec", "ready", "generate-spec"),
        ("spec", "awaiting-approval", "request-spec-approval"),
        ("design", "ready", "generate-design"),
        ("design", "awaiting-approval", "request-design-approval"),
        ("tasks", "ready", "generate-tasks"),
        ("tasks", "awaiting-approval", "request-tasks-approval"),
        ("implementation", "ready", "capture-implementation-scope"),
        ("code-review", "ready", "run-code-review"),
        ("code-review", "recorded", "record-code-review-gate"),
        ("auto-fix", "ready", "apply-review-findings"),
        (
            "auto-fix",
            "ready",
            "record-auto-fix-not-required-or-current-fixes",
        ),
        ("auto-fix", "recorded", "record-auto-fix-gate"),
        (
            "unit-test-summary",
            "ready",
            "generate-or-update-test-source",
        ),
        (
            "unit-test-summary",
            "ready",
            "generate-unit-test-summary-from-evidence",
        ),
        ("unit-test-summary", "recorded", "record-unit-test-gate"),
        (
            "unit-test-summary",
            "awaiting-approval",
            "request-unit-test-summary-approval",
        ),
        ("archive", "ready", "run-archive-check"),
        ("archive", "ready", "generate-archive-from-evidence"),
        ("archive", "awaiting-final-approval", "request-archive-approval"),
    }
    if (stage, status, action) in valid_static:
        if (
            action == "generate-unit-test-summary-from-evidence"
            and not isinstance(state.get("unit_test_execution"), dict)
        ):
            errors.append("UNIT_TEST_EXECUTION_STATE_MISSING")
        return errors

    if stage == "implementation" and status == "executing":
        required = state.get("required_phases", [])
        remaining = [
            phase
            for phase in required
            if state.get("phase_reviews", {}).get(phase, {}).get("status") != "approved"
        ]
        if action == "implement-next-approved-phase" and len(remaining) == len(required):
            return errors
        if remaining and action == f"implement-phase:{remaining[0]}":
            return errors
        if not remaining and action == "freeze-implementation-scope":
            return errors
    errors.append("INVALID_STATE_TRANSITION")
    return errors


def workflow_prerequisite_errors(
    feature_dir: Path,
    state: dict[str, Any],
    *,
    ignore_artifact_stage: str | None = None,
) -> list[str]:
    if state.get("execution_mode") == "historical-example":
        return []
    if (
        state.get("stage_status") in TERMINAL_STATUSES
        and state.get("stage_status") != "completed"
    ):
        return []
    stage = state.get("current_stage")
    if stage not in STAGE_ORDER:
        return []
    errors: list[str] = []
    artifacts = state.get("artifacts", {})

    required_artifacts: list[str] = ["brief-design"]
    if stage_index(stage) >= stage_index("spec"):
        required_artifacts.append("proposal-input")
    if stage_index(stage) >= stage_index("design"):
        required_artifacts.append("spec")
    if stage_index(stage) >= stage_index("tasks"):
        required_artifacts.append("design")
    if stage_index(stage) >= stage_index("implementation"):
        required_artifacts.append("tasks")
    if stage_index(stage) >= stage_index("auto-fix"):
        required_artifacts.append("code-review-findings")
    if stage_index(stage) >= stage_index("unit-test-summary"):
        required_artifacts.append("auto-fix-summary")
    if stage_index(stage) >= stage_index("archive"):
        required_artifacts.append("unit-test-summary")

    if stage == "spec" and state.get("stage_status") == "awaiting-approval":
        required_artifacts.append("spec")
    if stage == "design" and state.get("stage_status") == "awaiting-approval":
        required_artifacts.append("design")
    if stage == "tasks" and state.get("stage_status") == "awaiting-approval":
        required_artifacts.append("tasks")
    if (
        stage == "code-review"
        and (
            state.get("stage_status") == "recorded"
            or "code-review-findings" in artifacts
            or state.get("quality_gates", {}).get("code-review")
        )
    ):
        required_artifacts.append("code-review-findings")
    if (
        stage == "auto-fix"
        and (
            state.get("stage_status") == "recorded"
            or "auto-fix-summary" in artifacts
            or state.get("quality_gates", {}).get("auto-fix")
        )
    ):
        required_artifacts.append("auto-fix-summary")
    if (
        stage == "unit-test-summary"
        and (
            state.get("stage_status") in {"recorded", "awaiting-approval"}
            or state.get("quality_gates", {}).get("unit-test")
        )
    ):
        required_artifacts.append("unit-test-summary")
    if (
        stage == "archive"
        and state.get("stage_status") in {"awaiting-final-approval", "completed"}
    ):
        required_artifacts.append("archive")

    for artifact_stage in unique_in_order(required_artifacts):
        if artifact_stage not in artifacts:
            errors.append(f"WORKFLOW_ARTIFACT_MISSING:{artifact_stage}")

    required_approvals: list[str] = []
    if stage_index(stage) >= stage_index("design"):
        required_approvals.append("spec")
    if stage_index(stage) >= stage_index("tasks"):
        required_approvals.append("design")
    if stage_index(stage) >= stage_index("implementation"):
        required_approvals.append("tasks")
    for approval_stage in required_approvals:
        if approval_stage == ignore_artifact_stage:
            continue
        errors.extend(approval_errors(feature_dir, state, approval_stage))
    if stage_index(stage) >= stage_index("code-review"):
        for phase in state.get("required_phases", []):
            errors.extend(phase_review_errors(feature_dir, state, phase))
    if stage_index(stage) >= stage_index("auto-fix"):
        review = state.get("quality_gates", {}).get("code-review", {})
        if review.get("status") not in {"passed", "failed"}:
            errors.append("WORKFLOW_CODE_REVIEW_RESULT_MISSING")
    if stage_index(stage) >= stage_index("unit-test-summary"):
        review = state.get("quality_gates", {}).get("code-review", {})
        auto_fix = state.get("quality_gates", {}).get("auto-fix", {})
        if review.get("status") != "passed":
            errors.append("WORKFLOW_CODE_REVIEW_NOT_PASSED")
        if auto_fix.get("status") not in {"passed", "not-required"}:
            errors.append("WORKFLOW_AUTO_FIX_NOT_CLOSED")
    if stage_index(stage) >= stage_index("archive"):
        unit_test = state.get("quality_gates", {}).get("unit-test", {})
        if unit_test.get("status") != "passed":
            errors.append("WORKFLOW_UNIT_TEST_NOT_PASSED")
        errors.extend(approval_errors(feature_dir, state, "unit-test-summary"))
        if state.get("stage_status") == "completed":
            errors.extend(approval_errors(feature_dir, state, "archive"))
    return errors


def quality_gate_event_errors(
    feature_dir: Path,
    state: dict[str, Any],
) -> list[str]:
    events = read_jsonl(feature_paths(feature_dir)["events"])
    errors: list[str] = []
    for gate, projection in state.get("quality_gates", {}).items():
        if not isinstance(projection, dict):
            errors.append(f"QUALITY_GATE_STATE_INVALID:{gate}")
            continue
        if projection.get("status") in {"invalidated", "not-recorded"}:
            continue
        matches = [
            event
            for event in events
            if event.get("event_type") == "quality-gate-recorded"
            and event.get("attempt") == state.get("attempt")
            and event.get("payload", {}).get("gate") == gate
        ]
        if not matches:
            errors.append(f"QUALITY_GATE_EVENT_MISSING:{gate}")
            continue
        event_record = dict(matches[-1].get("payload", {}))
        event_record.pop("gate", None)
        if event_record != projection:
            errors.append(f"QUALITY_GATE_EVENT_BINDING_MISMATCH:{gate}")
    return errors


def scope_contract_payload(scope: dict[str, Any]) -> dict[str, Any]:
    fields = (
        "feature_id",
        "attempt",
        "repository_id",
        "feature_repo_path",
        "branch",
        "base_commit",
        "allowed_paths",
        "forbidden_paths",
        "required_phases",
        "production_change",
        "test_path_patterns",
    )
    if not isinstance(scope, dict) or any(field not in scope for field in fields):
        raise ControlError("SCOPE_MANIFEST_INVALID")
    return {field: scope[field] for field in fields}


def issue_implementation_permit(
    feature_dir: Path,
    state: dict[str, Any],
    scope: dict[str, Any],
) -> dict[str, Any]:
    approved_artifacts: dict[str, Any] = {}
    errors: list[str] = []
    for stage in ("spec", "design", "tasks"):
        errors.extend(approval_errors(feature_dir, state, stage))
        artifact = state["artifacts"].get(stage)
        approval = state["approvals"].get(stage)
        if artifact and approval:
            approved_artifacts[stage] = {
                "revision": artifact["revision"],
                "sha256": artifact["sha256"],
                "approval_id": approval["approval_id"],
            }
    if errors:
        raise ControlError(
            "IMPLEMENTATION_PERMIT_REJECTED:" + ",".join(sorted(set(errors)))
        )
    scope_contract_sha256 = sha256_bytes(
        canonical_json(scope_contract_payload(scope)).encode("utf-8")
    )
    permit: dict[str, Any] = {
        "status": "active",
        "feature_id": state["feature_id"],
        "attempt": state["attempt"],
        "issued_at": utc_now(),
        "approved_artifacts": approved_artifacts,
        "scope_contract_sha256": scope_contract_sha256,
    }
    permit["permit_sha256"] = sha256_bytes(
        canonical_json(permit).encode("utf-8")
    )
    scope["scope_contract_sha256"] = scope_contract_sha256
    scope["implementation_permit_sha256"] = permit["permit_sha256"]
    return permit


def implementation_permit_errors(
    feature_dir: Path,
    state: dict[str, Any],
    scope: dict[str, Any] | None = None,
) -> list[str]:
    permit = state.get("implementation_permit")
    if not isinstance(permit, dict) or permit.get("status") != "active":
        return ["IMPLEMENTATION_PERMIT_MISSING_OR_INACTIVE"]
    errors: list[str] = []
    if permit.get("feature_id") != state.get("feature_id"):
        errors.append("IMPLEMENTATION_PERMIT_FEATURE_MISMATCH")
    if permit.get("attempt") != state.get("attempt"):
        errors.append("IMPLEMENTATION_PERMIT_ATTEMPT_MISMATCH")
    body = dict(permit)
    actual_permit_sha256 = body.pop("permit_sha256", None)
    expected_permit_sha256 = sha256_bytes(canonical_json(body).encode("utf-8"))
    if actual_permit_sha256 != expected_permit_sha256:
        errors.append("IMPLEMENTATION_PERMIT_HASH_MISMATCH")
    for stage in ("spec", "design", "tasks"):
        errors.extend(approval_errors(feature_dir, state, stage))
        artifact = state.get("artifacts", {}).get(stage) or {}
        approval = state.get("approvals", {}).get(stage) or {}
        binding = permit.get("approved_artifacts", {}).get(stage) or {}
        if binding.get("revision") != artifact.get("revision"):
            errors.append(f"IMPLEMENTATION_PERMIT_ARTIFACT_REVISION_MISMATCH:{stage}")
        if binding.get("sha256") != artifact.get("sha256"):
            errors.append(f"IMPLEMENTATION_PERMIT_ARTIFACT_HASH_MISMATCH:{stage}")
        if binding.get("approval_id") != approval.get("approval_id"):
            errors.append(f"IMPLEMENTATION_PERMIT_APPROVAL_MISMATCH:{stage}")
    if scope is None:
        scope_path = feature_paths(feature_dir)["scope"]
        if not scope_path.is_file():
            errors.append("IMPLEMENTATION_PERMIT_SCOPE_MISSING")
            return sorted(set(errors))
        try:
            scope = load_scope(feature_dir)
        except ControlError:
            errors.append("SCOPE_MANIFEST_INVALID")
            return sorted(set(errors))
    try:
        scope_payload = scope_contract_payload(scope)
    except ControlError:
        errors.append("SCOPE_MANIFEST_INVALID")
        return sorted(set(errors))
    expected_scope_sha256 = sha256_bytes(canonical_json(scope_payload).encode("utf-8"))
    if scope.get("scope_contract_sha256") != expected_scope_sha256:
        errors.append("IMPLEMENTATION_PERMIT_SCOPE_CONTRACT_HASH_MISMATCH")
    if permit.get("scope_contract_sha256") != expected_scope_sha256:
        errors.append("IMPLEMENTATION_PERMIT_SCOPE_BINDING_MISMATCH")
    if scope.get("implementation_permit_sha256") != actual_permit_sha256:
        errors.append("IMPLEMENTATION_PERMIT_SCOPE_PERMIT_MISMATCH")
    return sorted(set(errors))


def assert_implementation_permit(
    feature_dir: Path,
    state: dict[str, Any],
    scope: dict[str, Any] | None = None,
) -> None:
    errors = implementation_permit_errors(feature_dir, state, scope)
    if errors:
        raise ControlError("IMPLEMENTATION_PERMIT_INVALID:" + ",".join(errors))


def revoke_implementation_permit(
    feature_dir: Path,
    state: dict[str, Any],
    reason: str,
) -> bool:
    permit = state.get("implementation_permit")
    if not isinstance(permit, dict):
        return False
    historical = dict(permit)
    historical["status"] = "invalidated"
    historical["invalidated_at"] = utc_now()
    historical["invalidated_reason"] = reason
    state.setdefault("implementation_permit_history", []).append(historical)
    state["implementation_permit"] = None
    state["required_phases"] = []
    feature_paths(feature_dir)["scope"].unlink(missing_ok=True)
    state["unit_test_execution"] = None
    feature_paths(feature_dir)["unit_test_evidence"].unlink(missing_ok=True)
    feature_paths(feature_dir)["archive_evidence"].unlink(missing_ok=True)
    return True


def quality_gate_errors(feature_dir: Path, state: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    try:
        scope = load_scope(feature_dir)
        current = snapshot_for_scope(scope_repo_root(feature_dir, scope), scope)
    except (ControlError, KeyError, TypeError, ValueError):
        return ["SCOPE_MANIFEST_INVALID"]
    if current["violations"]:
        errors.extend(current["violations"])
        return errors
    current_sha = current["snapshot_sha256"]
    accepted = {
        "code-review": {"passed"},
        "auto-fix": {"passed", "not-required"},
        "unit-test": {"passed"},
    }
    for gate, allowed in accepted.items():
        record = state.get("quality_gates", {}).get(gate)
        if not record or record.get("status") not in allowed:
            errors.append(f"QUALITY_GATE_NOT_PASSED:{gate}")
            continue
        if record.get("scope_sha256") != current_sha:
            errors.append(f"QUALITY_GATE_SCOPE_MISMATCH:{gate}")
        artifact_stage = {
            "code-review": "code-review-findings",
            "auto-fix": "auto-fix-summary",
            "unit-test": "unit-test-summary",
        }[gate]
        artifact = state.get("artifacts", {}).get(artifact_stage)
        if not artifact or record.get("artifact_sha256") != artifact.get("sha256"):
            errors.append(f"QUALITY_GATE_ARTIFACT_MISMATCH:{gate}")
        elif artifact.get("scope_sha256") != current_sha:
            errors.append(f"QUALITY_GATE_ARTIFACT_SCOPE_MISMATCH:{gate}")
        if gate == "unit-test" and record.get("status") == "passed":
            execution_errors = unit_test_execution_errors(
                feature_dir,
                state,
                required_outcome="passed",
            )
            errors.extend(execution_errors)
            execution = state.get("unit_test_execution") or {}
            if record.get("test_execution_sha256") != execution.get("evidence_sha256"):
                errors.append("QUALITY_GATE_TEST_EXECUTION_MISMATCH:unit-test")
    return errors


def archive_evidence_errors(feature_dir: Path, state: dict[str, Any]) -> list[str]:
    path = feature_paths(feature_dir)["archive_evidence"]
    if not path.is_file():
        return ["ARCHIVE_EVIDENCE_MISSING"]
    try:
        evidence = read_json(path)
    except ControlError:
        return ["ARCHIVE_EVIDENCE_INVALID"]
    try:
        scope = load_scope(feature_dir)
    except ControlError:
        return ["SCOPE_MANIFEST_INVALID"]
    if not isinstance(evidence, dict):
        return ["ARCHIVE_EVIDENCE_INVALID"]
    if not isinstance(scope, dict):
        return ["SCOPE_MANIFEST_INVALID"]
    frozen = scope.get("frozen_snapshot") or {}
    errors: list[str] = []
    expected = {
        "feature_id": state["feature_id"],
        "attempt": state["attempt"],
        "base_commit": scope.get("base_commit"),
        "head_commit": frozen.get("head_commit"),
        "head_tree": frozen.get("head_tree"),
        "scope_sha256": frozen.get("snapshot_sha256"),
        "unit_test_evidence_sha256": (
            state.get("quality_gates", {})
            .get("unit-test", {})
            .get("test_execution_sha256")
        ),
    }
    for key, value in expected.items():
        if evidence.get(key) != value:
            errors.append(f"ARCHIVE_EVIDENCE_MISMATCH:{key}")
    if evidence.get("files") != frozen.get("files"):
        errors.append("ARCHIVE_EVIDENCE_MISMATCH:files")
    if evidence.get("evidence_sha256") != sha256_bytes(
        canonical_json({key: value for key, value in evidence.items() if key != "evidence_sha256"}).encode("utf-8")
    ):
        errors.append("ARCHIVE_EVIDENCE_HASH_MISMATCH")
    return errors


def archive_errors(feature_dir: Path, state: dict[str, Any], require_archive: bool) -> list[str]:
    errors: list[str] = []
    errors.extend(verify_lock(feature_dir, state))
    errors.extend(validate_hash_chain(feature_paths(feature_dir)["events"], "event_hash"))
    errors.extend(validate_hash_chain(feature_paths(feature_dir)["approvals"], "record_hash"))
    errors.extend(state_event_projection_errors(feature_dir, state))
    errors.extend(state_transition_errors(state))
    errors.extend(approval_projection_errors(feature_dir, state))
    errors.extend(workflow_prerequisite_errors(feature_dir, state))
    errors.extend(quality_gate_event_errors(feature_dir, state))
    generation_errors = feature_generation_errors(feature_dir, state)
    errors.extend(generation_errors)
    if generation_errors:
        return sorted(set(errors))
    errors.extend(artifact_drift(feature_dir, state))
    for stage in ("spec", "design", "tasks", "unit-test-summary"):
        errors.extend(approval_errors(feature_dir, state, stage))
    for phase in state.get("required_phases", []):
        errors.extend(phase_review_errors(feature_dir, state, phase))
    if not feature_paths(feature_dir)["scope"].exists():
        errors.append("SCOPE_MANIFEST_MISSING")
    else:
        errors.extend(quality_gate_errors(feature_dir, state))
        errors.extend(archive_evidence_errors(feature_dir, state))
    required = list(ARTIFACT_FILES)
    if not require_archive:
        required.remove("archive")
    for stage in required:
        if stage not in state.get("artifacts", {}):
            errors.append(f"ARTIFACT_NOT_RECORDED:{stage}")
    if state.get("blocked"):
        errors.append("FEATURE_BLOCKED")
    return sorted(set(errors))


def validate_state(feature_dir: Path, state: dict[str, Any]) -> dict[str, list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    required = {
        "schema_version",
        "feature_id",
        "feature_dir",
        "execution_mode",
        "entry_contract",
        "revision",
        "attempt",
        "current_stage",
        "stage_status",
        "artifacts",
        "approvals",
        "quality_gates",
        "phase_reviews",
        "planning_baseline",
        "implementation_started",
        "implementation_permit",
        "next_required_action",
    }
    missing = sorted(required - set(state))
    errors.extend(f"STATE_FIELD_MISSING:{name}" for name in missing)
    if state.get("entry_contract", {}).get("user_entry") != "brief-prompt-and-skill-call":
        errors.append("USER_ENTRY_CONTRACT_CHANGED")
    if state.get("entry_contract", {}).get("developer_action_required") is not False:
        errors.append("USER_ENTRY_REQUIRES_NEW_ACTION")
    if state.get("current_stage") not in STAGE_ORDER:
        errors.append("INVALID_CURRENT_STAGE")
    errors.extend(state_transition_errors(state))
    errors.extend(verify_lock(feature_dir, state))
    errors.extend(artifact_drift(feature_dir, state))
    errors.extend(validate_hash_chain(feature_paths(feature_dir)["events"], "event_hash"))
    errors.extend(validate_hash_chain(feature_paths(feature_dir)["approvals"], "record_hash"))
    errors.extend(state_event_projection_errors(feature_dir, state))
    errors.extend(approval_projection_errors(feature_dir, state))
    errors.extend(workflow_prerequisite_errors(feature_dir, state))
    errors.extend(quality_gate_event_errors(feature_dir, state))
    events = read_jsonl(feature_paths(feature_dir)["events"])
    if events and events[-1].get("state_sha256") is None:
        warnings.append("LEGACY_STATE_EVENT_WITHOUT_PROJECTION_HASH")
    if state.get("execution_mode") != "historical-example":
        generation_errors = feature_generation_errors(feature_dir, state)
        errors.extend(generation_errors)
        if not generation_errors:
            if state.get("unit_test_execution") is not None:
                errors.extend(unit_test_execution_errors(feature_dir, state))
            errors.extend(planning_guard_errors(feature_dir, state))
            errors.extend(scope_drift(feature_dir, state))
            if (
                state.get("implementation_permit") is not None
                or feature_paths(feature_dir)["scope"].exists()
            ):
                errors.extend(implementation_permit_errors(feature_dir, state))
    else:
        warnings.append("HISTORICAL_EXAMPLE_NOT_VALID_GATE_EVIDENCE")
    return {"errors": sorted(set(errors)), "warnings": sorted(set(warnings))}


def assert_control_integrity(
    feature_dir: Path,
    state: dict[str, Any],
    *,
    ignore_artifact_stage: str | None = None,
    allow_scope_drift: bool = False,
) -> None:
    errors: list[str] = []
    errors.extend(verify_lock(feature_dir, state))
    errors.extend(validate_hash_chain(feature_paths(feature_dir)["events"], "event_hash"))
    errors.extend(validate_hash_chain(feature_paths(feature_dir)["approvals"], "record_hash"))
    errors.extend(state_event_projection_errors(feature_dir, state))
    errors.extend(state_transition_errors(state))
    errors.extend(approval_projection_errors(feature_dir, state))
    errors.extend(
        workflow_prerequisite_errors(
            feature_dir,
            state,
            ignore_artifact_stage=ignore_artifact_stage,
        )
    )
    errors.extend(quality_gate_event_errors(feature_dir, state))
    for error in artifact_drift(feature_dir, state):
        if ignore_artifact_stage and error.startswith((f"ARTIFACT_DRIFT:{ignore_artifact_stage}:", f"ARTIFACT_MISSING:{ignore_artifact_stage}:")):
            continue
        errors.append(error)
    generation_errors = feature_generation_errors(
        feature_dir,
        state,
        allow_unrecorded_stage=ignore_artifact_stage,
    )
    if generation_errors:
        if not errors and state.get("stage_status") not in TERMINAL_STATUSES:
            block_unexpected_feature_layout(
                feature_dir,
                state,
                generation_errors,
            )
        errors.extend(generation_errors)
    else:
        premature_errors = planning_guard_errors(feature_dir, state)
        if premature_errors:
            block_premature_implementation_change(
                feature_dir,
                state,
                premature_errors,
            )
            errors.extend(premature_errors)
    if (
        not generation_errors
        and (
            state.get("implementation_permit") is not None
            or feature_paths(feature_dir)["scope"].exists()
        )
        and ignore_artifact_stage not in {"brief-design", "proposal-input", "spec", "design", "tasks"}
    ):
        errors.extend(implementation_permit_errors(feature_dir, state))
    if not generation_errors and state.get("unit_test_execution") is not None:
        errors.extend(unit_test_execution_errors(feature_dir, state))
    if (
        not generation_errors
        and not allow_scope_drift
        and state.get("execution_mode") != "historical-example"
    ):
        errors.extend(scope_drift(feature_dir, state))
    if errors:
        raise ControlError("Control integrity check failed: " + ", ".join(sorted(set(errors))))


def assert_history_and_lock(feature_dir: Path, state: dict[str, Any]) -> None:
    errors = verify_lock(feature_dir, state)
    errors.extend(validate_hash_chain(feature_paths(feature_dir)["events"], "event_hash"))
    errors.extend(validate_hash_chain(feature_paths(feature_dir)["approvals"], "record_hash"))
    errors.extend(state_event_projection_errors(feature_dir, state))
    errors.extend(state_transition_errors(state))
    errors.extend(approval_projection_errors(feature_dir, state))
    errors.extend(workflow_prerequisite_errors(feature_dir, state))
    errors.extend(quality_gate_event_errors(feature_dir, state))
    if errors:
        raise ControlError("Control history check failed: " + ", ".join(sorted(set(errors))))


def assert_artifact_entry(
    feature_dir: Path,
    state: dict[str, Any],
    stage: str,
    previous: dict[str, Any] | None,
) -> None:
    revisable_planning = {"brief-design", "proposal-input", "spec", "design", "tasks"}
    if previous and stage in revisable_planning:
        return
    expected_stage = {
        "proposal-input": "proposal-input",
        "spec": "spec",
        "design": "design",
        "tasks": "tasks",
        "code-review-findings": "code-review",
        "auto-fix-summary": "auto-fix",
        "unit-test-summary": "unit-test-summary",
        "archive": "archive",
    }.get(stage)
    if expected_stage and state.get("current_stage") != expected_stage:
        raise ControlError(
            f"Cannot record {stage} while current_stage={state.get('current_stage')}; expected {expected_stage}"
        )
    if stage == "proposal-input" and "brief-design" not in state["artifacts"]:
        raise ControlError("proposal-input requires recorded brief-design")
    if stage == "spec" and "proposal-input" not in state["artifacts"]:
        raise ControlError("spec requires recorded proposal-input")
    if stage == "design":
        errors = approval_errors(feature_dir, state, "spec")
        if errors:
            raise ControlError("design requires current Spec approval: " + ", ".join(errors))
    if stage == "tasks":
        errors = approval_errors(feature_dir, state, "design")
        if errors:
            raise ControlError("tasks requires current Design approval: " + ", ".join(errors))
    if stage == "code-review-findings":
        errors = approval_errors(feature_dir, state, "tasks")
        for phase in state.get("required_phases", []):
            errors.extend(phase_review_errors(feature_dir, state, phase))
        require_current_scope(feature_dir, state)
        if errors:
            raise ControlError("Code Review findings entry blocked: " + ", ".join(errors))
    if stage == "auto-fix-summary":
        review = state.get("quality_gates", {}).get("code-review")
        if not review or review.get("status") not in {"passed", "failed"}:
            raise ControlError("Auto-fix summary requires a completed Code Review result")
    if stage == "unit-test-summary":
        errors = quality_gate_errors(feature_dir, state)
        errors = [error for error in errors if error != "QUALITY_GATE_NOT_PASSED:unit-test"]
        if errors:
            raise ControlError("Unit Test Summary entry blocked: " + ", ".join(errors))
        execution = state.get("unit_test_execution")
        if isinstance(execution, dict):
            errors = unit_test_execution_errors(feature_dir, state)
            if errors:
                raise ControlError(
                    "Unit Test Summary execution evidence is invalid: "
                    + ", ".join(errors)
                )
            content = (feature_dir / ARTIFACT_FILES[stage]).read_text(encoding="utf-8")
            for field in ("evidence_sha256", "scope_sha256"):
                if str(execution.get(field, "")) not in content:
                    raise ControlError(
                        f"Unit Test Summary must include current {field}"
                    )
    if stage == "archive":
        errors = archive_evidence_errors(feature_dir, state)
        if errors:
            raise ControlError("Archive entry blocked: " + ", ".join(errors))


def cmd_init(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    paths = feature_paths(feature_dir)
    if paths["state"].exists():
        raise ControlError(f"Feature is already initialized: {paths['state']}")
    repo_root = git_root(feature_dir)
    boundary_errors = feature_location_errors(repo_root, feature_dir)
    if boundary_errors:
        raise ControlError(
            "FEATURE_GENERATION_BOUNDARY_REJECTED:"
            + ",".join(boundary_errors)
        )
    feature_repo_path = feature_dir.relative_to(repo_root).as_posix()
    boundary_errors.extend(feature_layout_errors(feature_dir, None))
    boundary_errors.extend(
        uncontrolled_sibling_feature_errors(repo_root, feature_repo_path)
    )
    if boundary_errors:
        raise ControlError(
            "FEATURE_GENERATION_BOUNDARY_REJECTED:"
            + ",".join(sorted(set(boundary_errors)))
        )
    brief = feature_dir / ARTIFACT_FILES["brief-design"]
    if not brief.is_file():
        raise ControlError("brief-design.md must be persisted before SDD2 initialization")
    validate_artifact_language(brief, "brief-design")
    branch = run_git(repo_root, "branch", "--show-current")
    if not branch:
        raise ControlError("Detached HEAD is not allowed for an active SDD2 feature")
    installed_guards = install_git_guards(repo_root)
    acquire_lock(repo_root, feature_dir, args.feature_id)
    brief_digest = sha256_file(brief)
    brief_snapshot = persist_artifact_snapshot(feature_dir, "brief-design", 1, brief_digest)
    baseline = planning_snapshot(repo_root, feature_repo_path)
    state: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "feature_id": args.feature_id,
        "feature_dir": feature_repo_path,
        "feature_repo_path": feature_repo_path,
        "execution_mode": args.mode,
        "entry_contract": {
            "user_entry": "brief-prompt-and-skill-call",
            "developer_action_required": False,
            "version": 1,
        },
        "workspace_binding": {
            "repo_root": ".",
            "worktree": ".",
            "repository_id": repository_id(repo_root),
            "branch": branch,
        },
        "revision": 1,
        "attempt": 1,
        "current_stage": "proposal-input",
        "stage_status": "ready",
        "last_completed_stage": "brief-design",
        "next_required_action": "assemble-proposal-input",
        "blocked": None,
        "artifacts": {
            "brief-design": {
                "path": ARTIFACT_FILES["brief-design"],
                "revision": 1,
                "sha256": brief_digest,
                "snapshot_path": brief_snapshot,
                "status": "recorded",
                "recorded_at": utc_now(),
            }
        },
        "approvals": {},
        "quality_gates": {},
        "required_phases": [],
        "phase_reviews": {},
        "invalidations": [],
        "demo_authorization": None,
        "planning_baseline": baseline,
        "implementation_started": False,
        "implementation_permit": None,
        "implementation_permit_history": [],
        "unit_test_execution": None,
        "created_at": utc_now(),
        "updated_at": utc_now(),
    }
    paths["control"].mkdir(parents=True, exist_ok=True)
    paths["approvals"].touch()
    paths["events"].touch()
    save_state(feature_dir, state)
    append_event(
        feature_dir,
        state,
        "feature-initialized",
        {
            "mode": args.mode,
            "planning_baseline_sha256": baseline["snapshot_sha256"],
            "git_guards_installed": installed_guards,
        },
    )
    return state


def cmd_migrate_legacy(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    paths = feature_paths(feature_dir)
    if paths["state"].exists():
        raise ControlError("Legacy feature already has control state")
    repo_root = git_root(feature_dir)
    artifacts: dict[str, Any] = {}
    for stage, filename in ARTIFACT_FILES.items():
        path = feature_dir / filename
        if path.is_file():
            digest = sha256_file(path)
            artifacts[stage] = {
                "path": filename,
                "revision": 1,
                "sha256": digest,
                "snapshot_path": persist_artifact_snapshot(feature_dir, stage, 1, digest),
                "status": "historical-record",
                "recorded_at": utc_now(),
            }
    state = {
        "schema_version": SCHEMA_VERSION,
        "feature_id": args.feature_id,
        "feature_dir": feature_dir.relative_to(repo_root).as_posix(),
        "feature_repo_path": feature_dir.relative_to(repo_root).as_posix(),
        "execution_mode": "historical-example",
        "entry_contract": {
            "user_entry": "brief-prompt-and-skill-call",
            "developer_action_required": False,
            "version": 1,
        },
        "workspace_binding": {
            "repo_root": ".",
            "worktree": ".",
            "repository_id": repository_id(repo_root),
            "branch": run_git(repo_root, "branch", "--show-current"),
        },
        "revision": 1,
        "attempt": 1,
        "current_stage": "archive",
        "stage_status": "superseded",
        "last_completed_stage": None,
        "next_required_action": "none-historical-example",
        "blocked": {
            "code": "LEGACY_APPROVAL_EVIDENCE_UNVERIFIED",
            "reason": "Historical AI review records are not valid human approvals.",
            "recovery": "Run a new SDD2 attempt from a current brief; do not resume this example.",
        },
        "artifacts": artifacts,
        "approvals": {},
        "quality_gates": {},
        "required_phases": [],
        "phase_reviews": {},
        "invalidations": [],
        "demo_authorization": None,
        "planning_baseline": None,
        "implementation_started": False,
        "implementation_permit": None,
        "implementation_permit_history": [],
        "unit_test_execution": None,
        "created_at": utc_now(),
        "updated_at": utc_now(),
    }
    paths["control"].mkdir(parents=True, exist_ok=True)
    paths["approvals"].touch()
    paths["events"].touch()
    save_state(feature_dir, state)
    append_event(feature_dir, state, "legacy-example-quarantined", {"reason": state["blocked"]["code"]})
    return state


def cmd_authorize_demo(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    if state["execution_mode"] != "demo":
        raise ControlError("Demo authorization is only valid when execution_mode=demo")
    assert_control_integrity(feature_dir, state)
    lowered = args.authorization_text.lower()
    if (
        not any(term in lowered for term in DEMO_TERMS)
        or any(term in lowered for term in DEMO_REJECTION_TERMS)
        or not any(term in lowered for term in DEMO_ACTION_TERMS)
    ):
        raise ControlError("Demo authorization text must explicitly identify a demo/simulation")
    state["demo_authorization"] = {
        "source": "user-message",
        "message_id": args.message_id,
        "authorization_text": args.authorization_text,
        "authorized_at": utc_now(),
    }
    state["revision"] += 1
    append_event(feature_dir, state, "demo-authorized", dict(state["demo_authorization"]))
    save_state(feature_dir, state)
    return state


def cmd_record_artifact(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    if state["execution_mode"] == "historical-example":
        raise ControlError("Historical examples are immutable and cannot progress")
    stage = artifact_key_for_stage(args.stage)
    if state["stage_status"] in TERMINAL_STATUSES:
        raise ControlError("Terminal SDD2 attempts are immutable; restart a new attempt explicitly")
    assert_control_integrity(
        feature_dir,
        state,
        ignore_artifact_stage=stage,
        allow_scope_drift=True,
    )
    path = feature_dir / ARTIFACT_FILES[stage]
    validate_artifact_language(path, stage)
    digest = sha256_file(path)
    previous = state["artifacts"].get(stage)
    scope_sha256: str | None = None
    if stage in {"code-review-findings", "auto-fix-summary", "unit-test-summary", "archive"}:
        _, current_snapshot = require_current_scope(feature_dir, state)
        scope_sha256 = current_snapshot["snapshot_sha256"]
    if previous and previous.get("sha256") == digest:
        if scope_sha256 and previous.get("scope_sha256") != scope_sha256:
            raise ControlError(
                f"{stage} still describes an older implementation scope; update the artifact for the current scope"
            )
        return state
    assert_artifact_entry(feature_dir, state, stage, previous)
    revision = (previous or {}).get("revision", 0) + 1
    snapshot_path = persist_artifact_snapshot(feature_dir, stage, revision, digest)
    state["revision"] += 1
    invalidated: list[str] = []
    permit_revoked = False
    if previous:
        change_reason = f"{stage} changed from revision {previous['revision']} to {revision}"
        invalidated = invalidate_from(
            state,
            workflow_stage_for_artifact(stage),
            change_reason,
        )
        if stage in {"brief-design", "proposal-input", "spec", "design", "tasks"}:
            permit_revoked = revoke_implementation_permit(
                feature_dir,
                state,
                change_reason,
            )
    artifact_record: dict[str, Any] = {
        "path": ARTIFACT_FILES[stage],
        "revision": revision,
        "sha256": digest,
        "snapshot_path": snapshot_path,
        "status": "recorded",
        "recorded_at": utc_now(),
    }
    if scope_sha256:
        artifact_record["scope_sha256"] = scope_sha256
    state["artifacts"][stage] = artifact_record
    next_actions = {
        "brief-design": ("proposal-input", "ready", "assemble-proposal-input"),
        "proposal-input": ("spec", "ready", "generate-spec"),
        "spec": ("spec", "awaiting-approval", "request-spec-approval"),
        "design": ("design", "awaiting-approval", "request-design-approval"),
        "tasks": ("tasks", "awaiting-approval", "request-tasks-approval"),
        "code-review-findings": ("code-review", "recorded", "record-code-review-gate"),
        "auto-fix-summary": ("auto-fix", "recorded", "record-auto-fix-gate"),
        "unit-test-summary": ("unit-test-summary", "recorded", "record-unit-test-gate"),
        "archive": ("archive", "awaiting-final-approval", "request-archive-approval"),
    }
    current, status, action = next_actions[stage]
    state["current_stage"] = current
    state["stage_status"] = status
    state["next_required_action"] = action
    append_event(
        feature_dir,
        state,
        "artifact-recorded",
        {
            "stage": stage,
            "artifact_revision": revision,
            "sha256": digest,
            "invalidated": invalidated,
            "implementation_permit_revoked": permit_revoked,
        },
    )
    save_state(feature_dir, state)
    return state


def cmd_approve(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    assert_control_integrity(feature_dir, state)
    stage = args.stage
    if stage not in APPROVAL_STAGES:
        raise ControlError(f"Stage does not accept approval: {stage}")
    if stage not in state["artifacts"]:
        raise ControlError(f"Cannot approve missing artifact: {ARTIFACT_FILES[stage]}")
    expected_status = "awaiting-final-approval" if stage == "archive" else "awaiting-approval"
    if state.get("current_stage") != stage or state.get("stage_status") != expected_status:
        raise ControlError(
            f"Approval is not current: expected {stage}/{expected_status}, "
            f"found {state.get('current_stage')}/{state.get('stage_status')}"
        )
    if args.message_id and any(
        record.get("message_id") == args.message_id
        for record in read_jsonl(feature_paths(feature_dir)["approvals"])
    ):
        raise ControlError("This user message ID has already been used for an SDD2 approval")
    if current_artifact_hash(feature_dir, stage) != state["artifacts"][stage]["sha256"]:
        raise ControlError(f"Artifact drift detected before approval: {stage}")
    if not explicit_approval(stage, args.approval_text):
        raise ControlError(f"Approval text is ambiguous or does not identify the {stage} stage")
    if args.source == "user-message":
        if args.approver_role not in {"human", "user"}:
            raise ControlError("A real user-message approval must use approver_role=human or user")
    elif args.source == "demo-simulation":
        if state["execution_mode"] != "demo" or not state.get("demo_authorization"):
            raise ControlError("AI demo approval requires prior explicit user demo authorization")
        if args.approver_role != "ai-as-human-reviewer":
            raise ControlError("Demo simulation must identify approver_role=ai-as-human-reviewer")
    else:
        raise ControlError(f"Unsupported approval source: {args.source}")
    if stage == "archive":
        pre_errors = archive_errors(feature_dir, state, require_archive=True)
        pre_errors = [error for error in pre_errors if error != "APPROVAL_MISSING_OR_INVALID:archive"]
        if pre_errors:
            raise ControlError("Archive cannot be approved: " + ", ".join(pre_errors))
    if stage == "unit-test-summary":
        unit_gate = state.get("quality_gates", {}).get("unit-test")
        artifact = state["artifacts"]["unit-test-summary"]
        if (
            not unit_gate
            or unit_gate.get("status") != "passed"
            or unit_gate.get("artifact_sha256") != artifact.get("sha256")
            or unit_gate.get("scope_sha256") != artifact.get("scope_sha256")
        ):
            raise ControlError("Unit Test Summary approval requires a passed Unit Test gate on this artifact and scope")
    artifact = state["artifacts"][stage]
    approval = append_chained_record(
        feature_paths(feature_dir)["approvals"],
        {
            "approval_id": str(uuid.uuid4()),
            "timestamp": utc_now(),
            "feature_id": state["feature_id"],
            "attempt": state["attempt"],
            "stage": stage,
            "result": "approved",
            "source": args.source,
            "approver_role": args.approver_role,
            "message_id": args.message_id,
            "approval_text": args.approval_text,
            "artifact_path": artifact["path"],
            "artifact_revision": artifact["revision"],
            "artifact_sha256": artifact["sha256"],
        },
        "record_hash",
    )
    state["approvals"][stage] = {
        "approval_id": approval["approval_id"],
        "status": "approved",
        "attempt": state["attempt"],
        "artifact_revision": artifact["revision"],
        "artifact_sha256": artifact["sha256"],
        "record_hash": approval["record_hash"],
        "approved_at": approval["timestamp"],
    }
    transitions = {
        "spec": ("design", "ready", "generate-design"),
        "design": ("tasks", "ready", "generate-tasks"),
        "tasks": ("implementation", "ready", "capture-implementation-scope"),
        "unit-test-summary": ("archive", "ready", "run-archive-check"),
        "archive": ("archive", "completed", "none"),
    }
    state["current_stage"], state["stage_status"], state["next_required_action"] = transitions[stage]
    state["last_completed_stage"] = stage
    state["revision"] += 1
    append_event(
        feature_dir,
        state,
        "stage-approved",
        {"stage": stage, "approval_id": approval["approval_id"], "artifact_sha256": artifact["sha256"]},
    )
    save_state(feature_dir, state)
    if stage == "archive":
        release_lock(
            state_repo_root(feature_dir, state),
            feature_dir,
            state["feature_id"],
        )
    return state


def cmd_capture_scope(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    assert_control_integrity(feature_dir, state, allow_scope_drift=True)
    if state.get("current_stage") != "implementation" or state.get("stage_status") != "ready":
        raise ControlError("Implementation scope capture is only allowed immediately after current Tasks approval")
    errors = approval_errors(feature_dir, state, "tasks")
    if errors:
        raise ControlError("Tasks approval is required before implementation: " + ", ".join(errors))
    reject_unsafe_patterns(args.allowed_path)
    reject_unsafe_patterns(args.forbidden_path)
    reject_unsafe_patterns(args.test_path)
    if not args.required_phase:
        raise ControlError("Implementation scope requires at least one approved phase")
    repo_root = state_repo_root(feature_dir, state)
    branch = run_git(repo_root, "branch", "--show-current")
    if branch != state["workspace_binding"]["branch"]:
        raise ControlError("Git branch changed since feature initialization")
    base_commit = args.base_commit or run_git(repo_root, "rev-parse", "HEAD")
    run_git(repo_root, "cat-file", "-e", f"{base_commit}^{{commit}}")
    scope = {
        "schema_version": SCHEMA_VERSION,
        "feature_id": state["feature_id"],
        "attempt": state["attempt"],
        "repo_root": ".",
        "repository_id": repository_id(repo_root),
        "feature_repo_path": state["feature_repo_path"],
        "branch": branch,
        "base_commit": base_commit,
        "allowed_paths": sorted(set(args.allowed_path)),
        "forbidden_paths": sorted(set(args.forbidden_path)),
        "required_phases": unique_in_order(args.required_phase),
        "production_change": not args.non_production_change,
        "test_path_patterns": sorted(set(args.test_path or DEFAULT_TEST_PATHS)),
        "captured_at": utc_now(),
        "code_revision": 0,
        "frozen_snapshot": None,
    }
    initial = snapshot_for_scope(repo_root, scope)
    if initial["violations"]:
        raise ControlError("Pre-existing scope violations: " + ", ".join(initial["violations"]))
    if initial["files"]:
        dirty = ", ".join(item["path"] for item in initial["files"][:10])
        raise ControlError(
            "Implementation scope must start from a clean baseline; pre-existing changes found: " + dirty
        )
    scope["initial_snapshot"] = initial
    permit = issue_implementation_permit(feature_dir, state, scope)
    atomic_write_json(feature_paths(feature_dir)["scope"], scope)
    state["implementation_started"] = True
    state["implementation_permit"] = permit
    state["required_phases"] = scope["required_phases"]
    state["current_stage"] = "implementation"
    state["stage_status"] = "executing"
    state["next_required_action"] = "implement-next-approved-phase"
    state["revision"] += 1
    append_event(
        feature_dir,
        state,
        "implementation-scope-captured",
        {
            "base_commit": base_commit,
            "allowed_paths": scope["allowed_paths"],
            "required_phases": scope["required_phases"],
            "implementation_permit_sha256": permit["permit_sha256"],
        },
    )
    save_state(feature_dir, state)
    return scope


def cmd_phase_review(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    assert_control_integrity(feature_dir, state, allow_scope_drift=True)
    if state.get("current_stage") != "implementation":
        raise ControlError("Phase Review is only valid during implementation")
    if args.phase not in state.get("required_phases", []):
        raise ControlError(f"Phase is not declared in implementation scope: {args.phase}")
    next_phase = next(
        (
            phase
            for phase in state.get("required_phases", [])
            if state.get("phase_reviews", {}).get(phase, {}).get("status") != "approved"
        ),
        None,
    )
    if next_phase != args.phase:
        raise ControlError(f"Phase Review order violation: expected {next_phase!r}, received {args.phase!r}")
    if not direct_approval(args.approval_text, (args.phase, "phase review", "阶段")):
        raise ControlError("Phase approval must identify the phase and explicit approval result")
    if args.message_id and any(
        record.get("message_id") == args.message_id
        for record in read_jsonl(feature_paths(feature_dir)["approvals"])
    ):
        raise ControlError("This user message ID has already been used for an SDD2 approval")
    if args.message_id and any(
        review.get("message_id") == args.message_id
        for review in state.get("phase_reviews", {}).values()
    ):
        raise ControlError("This user message ID has already been used for an SDD2 approval")
    if args.source == "user-message":
        if args.approver_role not in {"human", "user"}:
            raise ControlError("A real user-message Phase Review must use approver_role=human or user")
    elif args.source == "demo-simulation":
        if state["execution_mode"] != "demo" or not state.get("demo_authorization"):
            raise ControlError("AI demo Phase Review requires prior explicit user demo authorization")
        if args.approver_role != "ai-as-human-reviewer":
            raise ControlError("Demo simulation must identify approver_role=ai-as-human-reviewer")
    else:
        raise ControlError(f"Unsupported Phase Review source: {args.source}")
    tasks_artifact = state["artifacts"]["tasks"]
    approval = append_chained_record(
        feature_paths(feature_dir)["approvals"],
        {
            "approval_id": str(uuid.uuid4()),
            "timestamp": utc_now(),
            "feature_id": state["feature_id"],
            "attempt": state["attempt"],
            "stage": f"phase-review:{args.phase}",
            "result": "approved",
            "source": args.source,
            "approver_role": args.approver_role,
            "message_id": args.message_id,
            "approval_text": args.approval_text,
            "artifact_path": tasks_artifact["path"],
            "artifact_revision": tasks_artifact["revision"],
            "artifact_sha256": tasks_artifact["sha256"],
        },
        "record_hash",
    )
    state["phase_reviews"][args.phase] = {
        "approval_id": approval["approval_id"],
        "record_hash": approval["record_hash"],
        "attempt": state["attempt"],
        "status": "approved",
        "source": args.source,
        "approver_role": args.approver_role,
        "message_id": args.message_id,
        "approval_text": args.approval_text,
        "approved_at": utc_now(),
        "tasks_revision": tasks_artifact["revision"],
        "tasks_sha256": tasks_artifact["sha256"],
    }
    state["revision"] += 1
    remaining = [
        phase
        for phase in state.get("required_phases", [])
        if state.get("phase_reviews", {}).get(phase, {}).get("status") != "approved"
    ]
    state["stage_status"] = "executing"
    state["next_required_action"] = (
        f"implement-phase:{remaining[0]}" if remaining else "freeze-implementation-scope"
    )
    append_event(
        feature_dir,
        state,
        "phase-approved",
        {"phase": args.phase, "source": args.source, "approver_role": args.approver_role},
    )
    save_state(feature_dir, state)
    return state


def cmd_freeze_scope(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    assert_control_integrity(feature_dir, state, allow_scope_drift=True)
    if state.get("current_stage") not in {"implementation", "code-review", "auto-fix", "unit-test-summary"}:
        raise ControlError(f"Scope freeze is not valid from current stage {state.get('current_stage')}")
    for phase in state.get("required_phases", []):
        errors = phase_review_errors(feature_dir, state, phase)
        if errors:
            raise ControlError(
                "Scope freeze requires current Phase Review approval: "
                + ", ".join(errors)
            )
    scope = load_scope(feature_dir)
    snapshot = snapshot_for_scope(scope_repo_root(feature_dir, scope), scope)
    if snapshot["violations"]:
        state["blocked"] = {
            "code": "IMPLEMENTATION_SCOPE_VIOLATION",
            "reason": ", ".join(snapshot["violations"]),
            "recovery": "Return to tasks scope approval or remove unrelated changes.",
        }
        state["stage_status"] = "blocked"
        state["next_required_action"] = "resolve-scope-violation"
        state["unit_test_execution"] = None
        feature_paths(feature_dir)["unit_test_evidence"].unlink(missing_ok=True)
        state["revision"] += 1
        append_event(
            feature_dir,
            state,
            "implementation-scope-violation-blocked",
            {"violations": snapshot["violations"]},
        )
        save_state(feature_dir, state)
        raise ControlError("Implementation scope violation: " + ", ".join(snapshot["violations"]))
    previous = scope.get("frozen_snapshot")
    if not previous or previous.get("snapshot_sha256") != snapshot["snapshot_sha256"]:
        scope["code_revision"] += 1
        invalidated = invalidate_from(state, "code-review", "Implementation snapshot changed")
        state["unit_test_execution"] = None
        feature_paths(feature_dir)["unit_test_evidence"].unlink(missing_ok=True)
        feature_paths(feature_dir)["archive_evidence"].unlink(missing_ok=True)
    else:
        invalidated = []
    snapshot["code_revision"] = scope["code_revision"]
    scope["frozen_snapshot"] = snapshot
    atomic_write_json(feature_paths(feature_dir)["scope"], scope)
    state["blocked"] = None
    state["current_stage"] = "code-review"
    state["stage_status"] = "ready"
    state["next_required_action"] = "run-code-review"
    state["revision"] += 1
    append_event(
        feature_dir,
        state,
        "implementation-scope-frozen",
        {"scope_sha256": snapshot["snapshot_sha256"], "code_revision": scope["code_revision"], "invalidated": invalidated},
    )
    save_state(feature_dir, state)
    return snapshot


def require_current_scope(feature_dir: Path, state: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    scope = load_scope(feature_dir)
    assert_implementation_permit(feature_dir, state, scope)
    snapshot = snapshot_for_scope(scope_repo_root(feature_dir, scope), scope)
    if snapshot["violations"]:
        raise ControlError("Scope violation: " + ", ".join(snapshot["violations"]))
    frozen = scope.get("frozen_snapshot")
    if not frozen or frozen.get("snapshot_sha256") != snapshot["snapshot_sha256"]:
        raise ControlError("Implementation scope changed; run freeze-scope and re-enter Code Review")
    return scope, snapshot


def process_output_text(value: str | bytes | None) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


def cmd_run_unit_test(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    assert_control_integrity(feature_dir, state)
    if (
        state.get("current_stage") != "unit-test-summary"
        or state.get("stage_status") != "ready"
        or state.get("next_required_action")
        not in {
            "generate-or-update-test-source",
            "generate-unit-test-summary-from-evidence",
        }
    ):
        raise ControlError(
            "Observed Unit Test execution is only valid after current Code Review and Auto-fix are closed"
        )
    if not 1 <= args.timeout_seconds <= 3600:
        raise ControlError("Unit Test timeout must be between 1 and 3600 seconds")

    scope, before_snapshot = require_current_scope(feature_dir, state)
    current_sha = before_snapshot["snapshot_sha256"]
    review = state.get("quality_gates", {}).get("code-review")
    auto_fix = state.get("quality_gates", {}).get("auto-fix")
    if not review or review.get("status") != "passed" or review.get("scope_sha256") != current_sha:
        raise ControlError("Unit Test execution requires Code Review passed on the current scope")
    if (
        not auto_fix
        or auto_fix.get("status") not in {"passed", "not-required"}
        or auto_fix.get("scope_sha256") != current_sha
    ):
        raise ControlError("Unit Test execution requires Auto-fix closed on the current scope")
    test_sources = changed_test_paths(scope, before_snapshot)
    if scope.get("production_change", True) and not test_sources:
        raise ControlError(
            "Unit Test execution requires at least one changed test source matching the captured test path patterns"
        )
    test_source_records = [
        item
        for item in before_snapshot["files"]
        if item["path"] in test_sources
    ]

    command = list(args.test_command)
    if command and command[0] == "--":
        command = command[1:]
    runner_kind = test_command_kind(command)
    cwd_value = Path(args.cwd)
    if cwd_value.is_absolute():
        raise ControlError("Unit Test cwd must be repository-relative")
    repo_root = scope_repo_root(feature_dir, scope)
    execution_cwd = (repo_root / cwd_value).resolve()
    try:
        execution_cwd.relative_to(repo_root)
    except ValueError as exc:
        raise ControlError("Unit Test cwd escapes the repository") from exc
    if not execution_cwd.is_dir():
        raise ControlError(f"Unit Test cwd does not exist: {args.cwd}")

    started_at = utc_now()
    stdout = ""
    stderr = ""
    exit_code: int | None = None
    timed_out = False
    launch_error: str | None = None
    environment = os.environ.copy()
    if runner_kind.startswith("python") or runner_kind == "pytest":
        environment.setdefault("PYTHONDONTWRITEBYTECODE", "1")
    try:
        process = subprocess.run(
            command,
            cwd=execution_cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=args.timeout_seconds,
            check=False,
            env=environment,
        )
        stdout = process.stdout
        stderr = process.stderr
        exit_code = process.returncode
    except subprocess.TimeoutExpired as exc:
        timed_out = True
        stdout = process_output_text(exc.stdout)
        stderr = process_output_text(exc.stderr)
    except OSError as exc:
        launch_error = f"{type(exc).__name__}: {exc}"
    completed_at = utc_now()

    after_snapshot = snapshot_for_scope(repo_root, scope)
    scope_changed = (
        bool(after_snapshot["violations"])
        or after_snapshot["snapshot_sha256"] != current_sha
    )
    counts = parsed_test_counts(stdout, stderr)
    failure_reason: str | None = None
    if timed_out:
        outcome = "blocked"
        failure_reason = "TEST_EXECUTION_TIMEOUT"
    elif launch_error:
        outcome = "blocked"
        failure_reason = "TEST_EXECUTION_LAUNCH_ERROR"
    elif scope_changed:
        outcome = "blocked"
        failure_reason = "TEST_CHANGED_FROZEN_SCOPE"
    elif exit_code != 0 or counts["failed"] > 0 or counts["errors"] > 0:
        outcome = "failed"
        failure_reason = "TEST_EXECUTION_FAILED"
    elif counts["total"] <= 0 or counts["passed"] <= 0:
        outcome = "blocked"
        failure_reason = "NO_EXECUTED_TEST_OBSERVED"
    else:
        outcome = "passed"

    evidence: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "feature_id": state["feature_id"],
        "attempt": state["attempt"],
        "scope_sha256": current_sha,
        "scope_after_sha256": after_snapshot["snapshot_sha256"],
        "scope_changed_during_test": scope_changed,
        "scope_violations": after_snapshot["violations"],
        "code_revision": scope["code_revision"],
        "runner_kind": runner_kind,
        "command": command,
        "cwd": execution_cwd.relative_to(repo_root).as_posix() or ".",
        "timeout_seconds": args.timeout_seconds,
        "started_at": started_at,
        "completed_at": completed_at,
        "exit_code": exit_code,
        "timed_out": timed_out,
        "launch_error": launch_error,
        "stdout_sha256": sha256_bytes(stdout.encode("utf-8")),
        "stderr_sha256": sha256_bytes(stderr.encode("utf-8")),
        "stdout_excerpt": bounded_output(stdout),
        "stderr_excerpt": bounded_output(stderr),
        "test_counts": counts,
        "changed_test_paths": test_sources,
        "changed_test_sources": test_source_records,
        "outcome": outcome,
        "failure_reason": failure_reason,
    }
    evidence["evidence_sha256"] = sha256_bytes(
        canonical_json(evidence).encode("utf-8")
    )
    atomic_write_json(feature_paths(feature_dir)["unit_test_evidence"], evidence)
    state["unit_test_execution"] = {
        "feature_id": state["feature_id"],
        "attempt": state["attempt"],
        "scope_sha256": current_sha,
        "code_revision": scope["code_revision"],
        "outcome": outcome,
        "evidence_sha256": evidence["evidence_sha256"],
        "recorded_at": completed_at,
    }
    if scope_changed:
        state["blocked"] = {
            "code": "UNIT_TEST_SCOPE_CHANGED",
            "reason": ", ".join(after_snapshot["violations"])
            or "Unit Test command changed the frozen implementation snapshot.",
            "recovery": "Remove generated scope changes or approve and refreeze them, then rerun full review and tests.",
        }
        state["stage_status"] = "blocked"
        state["next_required_action"] = "resolve-unit-test"
    else:
        state["blocked"] = None
        state["current_stage"] = "unit-test-summary"
        state["stage_status"] = "ready"
        state["next_required_action"] = "generate-unit-test-summary-from-evidence"
    state["revision"] += 1
    append_event(
        feature_dir,
        state,
        "unit-test-executed",
        {
            "evidence_sha256": evidence["evidence_sha256"],
            "scope_sha256": current_sha,
            "outcome": outcome,
            "exit_code": exit_code,
            "test_counts": counts,
        },
    )
    save_state(feature_dir, state)
    return evidence


def cmd_quality_gate(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    assert_control_integrity(feature_dir, state)
    gate = args.gate
    expected_stage = {"code-review": "code-review", "auto-fix": "auto-fix", "unit-test": "unit-test-summary"}[gate]
    if state.get("current_stage") != expected_stage:
        raise ControlError(
            f"{gate} gate is not current: expected stage {expected_stage}, found {state.get('current_stage')}"
        )
    if state.get("stage_status") != "recorded":
        raise ControlError(f"{gate} gate requires its current artifact to be recorded first")
    scope, snapshot = require_current_scope(feature_dir, state)
    current_sha = snapshot["snapshot_sha256"]
    if gate == "code-review":
        for stage in ("spec", "design", "tasks"):
            errors = approval_errors(feature_dir, state, stage)
            if errors:
                raise ControlError("Code Review blocked: " + ", ".join(errors))
        for phase in state.get("required_phases", []):
            errors = phase_review_errors(feature_dir, state, phase)
            if errors:
                raise ControlError("Code Review blocked: " + ", ".join(errors))
        if "code-review-findings" not in state["artifacts"]:
            raise ControlError("code-review-findings.md must be recorded before the Code Review gate")
        allowed = {"passed", "failed", "blocked"}
    elif gate == "auto-fix":
        review = state.get("quality_gates", {}).get("code-review")
        if not review or review.get("status") != "passed" or review.get("scope_sha256") != current_sha:
            raise ControlError("Auto-fix requires Code Review passed on the current scope")
        if "auto-fix-summary" not in state["artifacts"]:
            raise ControlError("auto-fix-summary.md must be recorded before the Auto-fix gate")
        allowed = {"passed", "not-required", "failed", "blocked"}
    else:
        review = state.get("quality_gates", {}).get("code-review")
        auto_fix = state.get("quality_gates", {}).get("auto-fix")
        if not review or review.get("status") != "passed" or review.get("scope_sha256") != current_sha:
            raise ControlError("Unit Test requires Code Review passed on the current scope")
        if not auto_fix or auto_fix.get("status") not in {"passed", "not-required"} or auto_fix.get("scope_sha256") != current_sha:
            raise ControlError("Unit Test requires Auto-fix closed on the current scope")
        if "unit-test-summary" not in state["artifacts"]:
            raise ControlError("unit-test-summary.md must be recorded before the Unit Test gate")
        if scope.get("production_change", True) and not changed_test_paths(scope, snapshot):
            raise ControlError(
                "Unit Test requires at least one changed test source matching the captured test path patterns"
            )
        allowed = {"passed", "failed", "blocked", "not-run"}
    if args.result not in allowed:
        raise ControlError(f"Invalid {gate} result: {args.result}; expected one of {sorted(allowed)}")
    if not args.evidence.strip():
        raise ControlError(f"{gate} requires non-empty reproducible evidence")
    if gate == "unit-test" and args.result in {"passed", "failed"}:
        errors = unit_test_execution_errors(
            feature_dir,
            state,
            required_outcome=args.result,
        )
        if errors:
            raise ControlError(
                "Unit Test gate requires controller-observed execution: "
                + ", ".join(errors)
            )
        if (
            state.get("unit_test_execution", {}).get("scope_sha256")
            != current_sha
        ):
            raise ControlError(
                "Unit Test execution evidence belongs to a different implementation scope"
            )
    record = {
        "status": args.result,
        "recorded_at": utc_now(),
        "scope_sha256": current_sha,
        "code_revision": scope["code_revision"],
        "evidence": args.evidence,
    }
    artifact_stage = {
        "code-review": "code-review-findings",
        "auto-fix": "auto-fix-summary",
        "unit-test": "unit-test-summary",
    }[gate]
    record["artifact_sha256"] = state["artifacts"][artifact_stage]["sha256"]
    if gate == "unit-test":
        record["changed_test_paths"] = changed_test_paths(scope, snapshot)
        execution = state.get("unit_test_execution") or {}
        if execution.get("evidence_sha256"):
            record["test_execution_sha256"] = execution["evidence_sha256"]
    state["quality_gates"][gate] = record
    if gate == "code-review":
        if args.result == "blocked":
            state["stage_status"] = "blocked"
            state["blocked"] = {
                "code": "CODE_REVIEW_BLOCKED",
                "reason": args.evidence,
                "recovery": "Resolve review input/scope evidence and rerun Code Review.",
            }
            state["next_required_action"] = "resolve-code-review"
        else:
            state["blocked"] = None
            state["current_stage"] = "auto-fix"
            state["stage_status"] = "ready"
            state["next_required_action"] = (
                "apply-review-findings" if args.result == "failed" else "record-auto-fix-not-required-or-current-fixes"
            )
    elif gate == "auto-fix":
        if args.result in {"failed", "blocked"}:
            state["stage_status"] = "blocked"
            state["blocked"] = {
                "code": f"AUTO_FIX_{args.result.upper()}",
                "reason": args.evidence,
                "recovery": "Resolve Auto-fix evidence or implementation and rerun from the current frozen scope.",
            }
            state["next_required_action"] = "resolve-auto-fix"
        else:
            state["blocked"] = None
            state["current_stage"] = "unit-test-summary"
            state["stage_status"] = "ready"
            state["next_required_action"] = "generate-or-update-test-source"
    elif args.result != "passed":
        state["stage_status"] = "blocked"
        state["blocked"] = {
            "code": f"UNIT_TEST_{args.result.upper().replace('-', '_')}",
            "reason": args.evidence,
            "recovery": "Fix/generate tests and implementation as needed, then refreeze, re-review, and rerun tests.",
        }
        state["next_required_action"] = "resolve-unit-test"
    else:
        state["blocked"] = None
        state["current_stage"] = "unit-test-summary"
        state["stage_status"] = "awaiting-approval"
        state["next_required_action"] = "request-unit-test-summary-approval"
    state["revision"] += 1
    append_event(feature_dir, state, "quality-gate-recorded", {"gate": gate, **record})
    save_state(feature_dir, state)
    return state


def cmd_validate(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    result = validate_state(feature_dir, state)
    if args.next_stage:
        if args.next_stage in APPROVAL_STAGES and args.next_stage != "archive":
            previous = {
                "design": "spec",
                "tasks": "design",
                "unit-test-summary": "tasks",
            }.get(args.next_stage)
            if previous:
                result["errors"].extend(approval_errors(feature_dir, state, previous))
        if args.next_stage == "archive":
            result["errors"].extend(archive_errors(feature_dir, state, require_archive=False))
    result["errors"] = sorted(set(result["errors"]))
    result["valid"] = not result["errors"]
    return result


def cmd_archive_check(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    errors = archive_errors(feature_dir, state, require_archive=args.require_archive)
    return {"valid": not errors, "errors": errors}


def cmd_prepare_archive(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    assert_control_integrity(feature_dir, state)
    if state.get("current_stage") != "archive" or state.get("stage_status") != "ready":
        raise ControlError("Archive evidence is only prepared after current Unit Test Summary approval")
    errors = approval_errors(feature_dir, state, "unit-test-summary")
    if feature_paths(feature_dir)["scope"].exists():
        errors.extend(quality_gate_errors(feature_dir, state))
    else:
        errors.append("SCOPE_MANIFEST_MISSING")
    if errors:
        raise ControlError("Archive evidence cannot be prepared: " + ", ".join(sorted(set(errors))))
    scope = load_scope(feature_dir)
    frozen = scope.get("frozen_snapshot")
    if not frozen:
        raise ControlError("Archive evidence requires a frozen implementation scope")
    evidence: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "feature_id": state["feature_id"],
        "attempt": state["attempt"],
        "branch": scope["branch"],
        "base_commit": scope["base_commit"],
        "head_commit": frozen["head_commit"],
        "head_tree": frozen["head_tree"],
        "scope_sha256": frozen["snapshot_sha256"],
        "unit_test_evidence_sha256": state["quality_gates"]["unit-test"][
            "test_execution_sha256"
        ],
        "files": frozen["files"],
    }
    existing_path = feature_paths(feature_dir)["archive_evidence"]
    if existing_path.is_file():
        existing = read_json(existing_path)
        comparable = {key: value for key, value in existing.items() if key not in {"generated_at", "evidence_sha256"}}
        if comparable == evidence:
            if state.get("next_required_action") == "generate-archive-from-evidence":
                return existing
            evidence = existing
    if "evidence_sha256" not in evidence:
        evidence["generated_at"] = utc_now()
        evidence["evidence_sha256"] = sha256_bytes(canonical_json(evidence).encode("utf-8"))
        atomic_write_json(feature_paths(feature_dir)["archive_evidence"], evidence)
    state["revision"] += 1
    state["current_stage"] = "archive"
    state["stage_status"] = "ready"
    state["next_required_action"] = "generate-archive-from-evidence"
    append_event(
        feature_dir,
        state,
        "archive-evidence-prepared",
        {"evidence_sha256": evidence["evidence_sha256"], "scope_sha256": evidence["scope_sha256"]},
    )
    save_state(feature_dir, state)
    return evidence


def cmd_resume(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    installed_guards: list[str] = []
    if state["execution_mode"] != "historical-example" and state["stage_status"] not in TERMINAL_STATUSES:
        repo_root = state_repo_root(feature_dir, state)
        acquire_lock(
            repo_root,
            feature_dir,
            state["feature_id"],
        )
        installed_guards = install_git_guards(repo_root)
        history_errors = verify_lock(feature_dir, state)
        history_errors.extend(
            validate_hash_chain(feature_paths(feature_dir)["events"], "event_hash")
        )
        history_errors.extend(
            validate_hash_chain(
                feature_paths(feature_dir)["approvals"],
                "record_hash",
            )
        )
        history_errors.extend(state_event_projection_errors(feature_dir, state))
        history_errors.extend(state_transition_errors(state))
        history_errors.extend(approval_projection_errors(feature_dir, state))
        history_errors.extend(workflow_prerequisite_errors(feature_dir, state))
        history_errors.extend(quality_gate_event_errors(feature_dir, state))
        if not history_errors:
            generation_errors = feature_generation_errors(feature_dir, state)
            if generation_errors:
                block_unexpected_feature_layout(
                    feature_dir,
                    state,
                    generation_errors,
                )
            else:
                if (state.get("blocked") or {}).get("code") == FEATURE_LAYOUT_BLOCK:
                    restore_unexpected_feature_layout_block(feature_dir, state)
                premature_errors = planning_guard_errors(feature_dir, state)
                if premature_errors:
                    block_premature_implementation_change(
                        feature_dir,
                        state,
                        premature_errors,
                    )
                elif (state.get("blocked") or {}).get("code") == PREMATURE_CHANGE_BLOCK:
                    restore_premature_change_block(feature_dir, state)
    validation = validate_state(feature_dir, state)
    return {
        "valid": not validation["errors"],
        "feature_id": state["feature_id"],
        "execution_mode": state["execution_mode"],
        "current_stage": state["current_stage"],
        "stage_status": state["stage_status"],
        "next_required_action": state["next_required_action"],
        "blocked": state.get("blocked"),
        "revision": state["revision"],
        "attempt": state["attempt"],
        "implementation_permit_status": (
            state.get("implementation_permit") or {}
        ).get("status"),
        "git_guards_installed": installed_guards,
        "validation": validation,
    }


def cmd_close(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    assert_history_and_lock(feature_dir, state)
    if state.get("stage_status") in TERMINAL_STATUSES:
        raise ControlError("Terminal attempts are immutable; use restart-attempt for new work")
    lowered = args.approval_text.lower()
    if not any(term in lowered for term in ("风险", "risk", "终止", "abort", "关闭", "close")):
        raise ControlError("Closure approval must explicitly mention risk acceptance or abort/close")
    if args.result == "closed-with-risk" and not state.get("blocked"):
        raise ControlError("closed-with-risk is only valid for a recorded blocked/failed workflow")
    state["current_stage"] = "archive"
    state["stage_status"] = args.result
    state["next_required_action"] = "none"
    state["revision"] += 1
    append_event(
        feature_dir,
        state,
        "workflow-closed",
        {
            "result": args.result,
            "source": "user-message",
            "message_id": args.message_id,
            "approval_text": args.approval_text,
        },
    )
    save_state(feature_dir, state)
    release_lock(
        state_repo_root(feature_dir, state),
        feature_dir,
        state["feature_id"],
    )
    return state


def cmd_restart_attempt(args: argparse.Namespace) -> dict[str, Any]:
    feature_dir = normalize_feature_dir(args.feature_dir)
    state = load_state(feature_dir)
    assert_history_and_lock(feature_dir, state)
    generation_errors = feature_generation_errors(feature_dir, state)
    if generation_errors:
        raise ControlError(
            "Unexpected Feature paths must be removed before restart: "
            + ", ".join(generation_errors)
        )
    if (state.get("blocked") or {}).get("code") == PREMATURE_CHANGE_BLOCK:
        errors = planning_guard_errors(feature_dir, state)
        if errors:
            raise ControlError(
                "Premature implementation changes must be restored before restart: "
                + ", ".join(errors)
            )
    if state["execution_mode"] == "historical-example":
        raise ControlError("Historical examples cannot start a new attempt")
    if state["stage_status"] != "blocked" and state["stage_status"] not in TERMINAL_STATUSES:
        raise ControlError("A new attempt is only allowed after a blocked or terminal attempt")
    lowered = args.approval_text.lower()
    if not any(term in lowered for term in ("重试", "重新开始", "retry", "restart")):
        raise ControlError("New-attempt approval must explicitly request retry or restart")
    acquire_lock(
        state_repo_root(feature_dir, state),
        feature_dir,
        state["feature_id"],
    )
    old_attempt = state["attempt"]
    state["attempt"] += 1
    state["revision"] += 1
    for approval in state.get("approvals", {}).values():
        approval["status"] = "invalidated"
        approval["invalidated_reason"] = f"Attempt {old_attempt} ended; fresh approval is required"
    state["quality_gates"] = {}
    state["phase_reviews"] = {}
    state["required_phases"] = []
    if state.get("implementation_permit") is not None:
        revoke_implementation_permit(
            feature_dir,
            state,
            f"Attempt {old_attempt} ended",
        )
    state["planning_baseline"] = planning_snapshot(
        state_repo_root(feature_dir, state),
        state["feature_repo_path"],
    )
    state["implementation_started"] = False
    state["implementation_permit"] = None
    state["unit_test_execution"] = None
    state["blocked"] = None
    state["last_completed_stage"] = "brief-design"
    if "spec" in state["artifacts"]:
        state["current_stage"] = "spec"
        state["stage_status"] = "awaiting-approval"
        state["next_required_action"] = "request-spec-approval"
    elif "proposal-input" in state["artifacts"]:
        state["current_stage"] = "spec"
        state["stage_status"] = "ready"
        state["next_required_action"] = "generate-spec"
    else:
        state["current_stage"] = "proposal-input"
        state["stage_status"] = "ready"
        state["next_required_action"] = "assemble-proposal-input"
    for key in ("scope", "unit_test_evidence", "archive_evidence"):
        feature_paths(feature_dir)[key].unlink(missing_ok=True)
    append_event(
        feature_dir,
        state,
        "attempt-restarted",
        {
            "previous_attempt": old_attempt,
            "source": "user-message",
            "message_id": args.message_id,
            "approval_text": args.approval_text,
        },
    )
    save_state(feature_dir, state)
    return state


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="Initialize active SDD2 state after brief-design.md is persisted")
    init.add_argument("--feature-dir", required=True)
    init.add_argument("--feature-id", required=True)
    init.add_argument("--mode", choices=["real", "demo"], default="real")
    init.set_defaults(handler=cmd_init)

    legacy = sub.add_parser("migrate-legacy", help="Quarantine a historical sample without backfilling approval evidence")
    legacy.add_argument("--feature-dir", required=True)
    legacy.add_argument("--feature-id", required=True)
    legacy.set_defaults(handler=cmd_migrate_legacy)

    demo = sub.add_parser("authorize-demo", help="Record explicit user authorization before simulated AI approvals")
    demo.add_argument("--feature-dir", required=True)
    demo.add_argument("--authorization-text", required=True)
    demo.add_argument("--message-id")
    demo.set_defaults(handler=cmd_authorize_demo)

    artifact = sub.add_parser("record-artifact", help="Hash and version a generated or updated core artifact")
    artifact.add_argument("--feature-dir", required=True)
    artifact.add_argument("--stage", required=True, choices=sorted(ARTIFACT_FILES))
    artifact.set_defaults(handler=cmd_record_artifact)

    approve = sub.add_parser("approve", help="Persist a stage approval bound to the current artifact revision")
    approve.add_argument("--feature-dir", required=True)
    approve.add_argument("--stage", required=True, choices=sorted(APPROVAL_STAGES))
    approve.add_argument("--source", required=True, choices=["user-message", "demo-simulation"])
    approve.add_argument("--approver-role", required=True)
    approve.add_argument("--approval-text", required=True)
    approve.add_argument("--message-id")
    approve.set_defaults(handler=cmd_approve)

    scope = sub.add_parser("capture-scope", help="Bind implementation to a Git baseline and approved path manifest")
    scope.add_argument("--feature-dir", required=True)
    scope.add_argument("--base-commit")
    scope.add_argument("--allowed-path", action="append", required=True)
    scope.add_argument("--forbidden-path", action="append", default=[])
    scope.add_argument("--required-phase", action="append", default=[])
    scope.add_argument("--test-path", action="append", default=[])
    scope.add_argument("--non-production-change", action="store_true")
    scope.set_defaults(handler=cmd_capture_scope)

    phase = sub.add_parser("phase-review", help="Record an approval with explicit provenance for one implementation phase")
    phase.add_argument("--feature-dir", required=True)
    phase.add_argument("--phase", required=True)
    phase.add_argument("--source", required=True, choices=["user-message", "demo-simulation"])
    phase.add_argument("--approver-role", required=True)
    phase.add_argument("--approval-text", required=True)
    phase.add_argument("--message-id")
    phase.set_defaults(handler=cmd_phase_review)

    freeze = sub.add_parser("freeze-scope", help="Freeze the current implementation snapshot before quality review")
    freeze.add_argument("--feature-dir", required=True)
    freeze.set_defaults(handler=cmd_freeze_scope)

    run_test = sub.add_parser("run-unit-test", help="Execute a recognized test runner and persist observed evidence")
    run_test.add_argument("--feature-dir", required=True)
    run_test.add_argument("--cwd", default=".")
    run_test.add_argument("--timeout-seconds", type=int, default=600)
    run_test.add_argument("test_command", nargs=argparse.REMAINDER)
    run_test.set_defaults(handler=cmd_run_unit_test)

    gate = sub.add_parser("quality-gate", help="Record Code Review, Auto-fix, or Unit Test against a frozen scope")
    gate.add_argument("--feature-dir", required=True)
    gate.add_argument("--gate", required=True, choices=sorted(QUALITY_GATES))
    gate.add_argument("--result", required=True)
    gate.add_argument("--evidence", required=True)
    gate.set_defaults(handler=cmd_quality_gate)

    validate = sub.add_parser("validate", help="Validate state, hash chains, artifacts, lock, and scope")
    validate.add_argument("--feature-dir", required=True)
    validate.add_argument("--next-stage", choices=STAGE_ORDER)
    validate.set_defaults(handler=cmd_validate)

    archive = sub.add_parser("archive-check", help="Validate Archive prerequisites")
    archive.add_argument("--feature-dir", required=True)
    archive.add_argument("--require-archive", action="store_true")
    archive.set_defaults(handler=cmd_archive_check)

    prepare_archive = sub.add_parser("prepare-archive", help="Persist immutable Git and scope evidence for Archive")
    prepare_archive.add_argument("--feature-dir", required=True)
    prepare_archive.set_defaults(handler=cmd_prepare_archive)

    resume = sub.add_parser("resume", help="Return the only valid resume point for a feature")
    resume.add_argument("--feature-dir", required=True)
    resume.set_defaults(handler=cmd_resume)

    close = sub.add_parser("close", help="Close a failed workflow without marking successful delivery")
    close.add_argument("--feature-dir", required=True)
    close.add_argument("--result", required=True, choices=["closed-with-risk", "aborted"])
    close.add_argument("--approval-text", required=True)
    close.add_argument("--message-id")
    close.set_defaults(handler=cmd_close)

    restart = sub.add_parser("restart-attempt", help="Start a fresh attempt after explicit user retry approval")
    restart.add_argument("--feature-dir", required=True)
    restart.add_argument("--approval-text", required=True)
    restart.add_argument("--message-id")
    restart.set_defaults(handler=cmd_restart_attempt)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        result = args.handler(args)
    except ControlError as exc:
        print(canonical_json({"ok": False, "error": str(exc)}))
        return 2
    ok = result.get("valid", True) if isinstance(result, dict) else True
    print(json.dumps({"ok": ok, "result": result}, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
